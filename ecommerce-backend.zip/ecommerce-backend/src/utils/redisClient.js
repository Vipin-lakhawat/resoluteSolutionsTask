const Redis = require('redis');

let redisClient;

const initRedis = async () => {
  redisClient = Redis.createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
  });

  redisClient.on('error', (err) => {
    console.error('❌ Redis Client Error:', err);
  });

  await redisClient.connect();
  console.log('✅ Redis connected successfully');
  return redisClient;
};

const getRedisClient = () => {
  if (!redisClient) {
    throw new Error('Redis client not initialized! Call initRedis() first.');
  }
  return redisClient;
};

module.exports = { initRedis, getRedisClient };
