const Joi = require('joi');

const registerValidation = Joi.object({
  name: Joi.string().min(2).max(50).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('USER', 'ADMIN').default('USER')
});

const loginValidation = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required()
});

const productValidation = Joi.object({
  name: Joi.string().min(2).max(100).required(),
  price: Joi.number().min(0).required(),
  description: Joi.string().min(10).required(),
  availableStock: Joi.number().min(0).required()
});

const cartItemValidation = Joi.object({
  productId: Joi.string().hex().length(24).required(),
  quantity: Joi.number().min(1).required()
});

const orderStatusValidation = Joi.object({
  status: Joi.string().valid('SHIPPED', 'DELIVERED').required()
});

const paginationValidation = Joi.object({
  page: Joi.number().min(1).default(1),
  limit: Joi.number().min(1).max(100).default(10),
  sort: Joi.string().optional(),
  filter: Joi.string().optional()
});

const validate = (schema) => {
  return (req, res, next) => {
    const { error } = schema.validate(req.body);
    if (error) {
      return res.status(400).json({
        success: false,
        message: error.details[0].message
      });
    }
    next();
  };
};

module.exports = {
  registerValidation,
  loginValidation,
  productValidation,
  cartItemValidation,
  orderStatusValidation,
  paginationValidation,
  validate
};