const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { cartItemValidation, validate } = require('../utils/validation');

const getCart = async (req, res, next) => {
  try {
    let cart = await Cart.findOne({ userId: req.user._id }).populate('items.productId');

    if (!cart) {
      cart = await Cart.create({ userId: req.user._id, items: [] });
    }

    res.json({
      success: true,
      data: cart
    });
  } catch (error) {
    next(error);
  }
};

const addToCart = [
  validate(cartItemValidation),
  async (req, res, next) => {
    const session = await Cart.startSession();
    
    try {
      session.startTransaction();

      const { productId, quantity } = req.body;

    
      const product = await Product.findById(productId).session(session);
      if (!product) {
        await session.abortTransaction();
        return res.status(404).json({
          success: false,
          message: 'Product not found'
        });
      }

      if (product.availableStock < quantity) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: `Insufficient stock. Available: ${product.availableStock}`
        });
      }

      let cart = await Cart.findOne({ userId: req.user._id }).session(session);
      if (!cart) {
        cart = await Cart.create([{ userId: req.user._id, items: [] }], { session });
        cart = cart[0];
      }

      const existingItemIndex = cart.items.findIndex(
        item => item.productId.toString() === productId
      );

      if (existingItemIndex > -1) {
        const newQuantity = cart.items[existingItemIndex].quantity + quantity;
        
        if (product.availableStock < newQuantity) {
          await session.abortTransaction();
          return res.status(400).json({
            success: false,
            message: `Insufficient stock for additional quantity. Available: ${product.availableStock}`
          });
        }
        
        cart.items[existingItemIndex].quantity = newQuantity;
      } else {
        cart.items.push({ productId, quantity });
      }

      await cart.save({ session });
      await session.commitTransaction();

      await cart.populate('items.productId');

      res.json({
        success: true,
        data: cart
      });
    } catch (error) {
      await session.abortTransaction();
      next(error);
    } finally {
      session.endSession();
    }
  }
];

const removeFromCart = async (req, res, next) => {
  try {
    const cart = await Cart.findOne({ userId: req.user._id });
    
    if (!cart) {
      return res.status(404).json({
        success: false,
        message: 'Cart not found'
      });
    }

    cart.items = cart.items.filter(
      item => item.productId.toString() !== req.params.productId
    );

    await cart.save();
    await cart.populate('items.productId');

    res.json({
      success: true,
      data: cart
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getCart,
  addToCart,
  removeFromCart
};