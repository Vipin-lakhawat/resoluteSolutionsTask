const mongoose = require('mongoose'); 
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const Payment = require('../models/Payment');
const emailQueueService = require('../services/emailQueue');
const orderExpiryService = require('../services/orderExpiryService');

const checkout = async (req, res, next) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();

    const cart = await Cart.findOne({ userId: req.user._id })
      .populate('items.productId')
      .session(session);
    
    if (!cart || cart.items.length === 0) {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: 'Cart is empty'
      });
    }

    const orderItems = [];
    
    for (const cartItem of cart.items) {
      const product = cartItem.productId;
      
      if (!product) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: `Product not found for item: ${cartItem.productId}`
        });
      }
      
      if (product.availableStock < cartItem.quantity) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${product.name}. Available: ${product.availableStock}, Requested: ${cartItem.quantity}`
        });
      }

      await Product.reserveStock(product._id, cartItem.quantity, session);
      
      orderItems.push({
        productId: product._id,
        quantity: cartItem.quantity,
        priceAtPurchase: product.price
      });
    }

 
    const order = await Order.create([{
      userId: req.user._id,
      items: orderItems,
      status: 'PENDING_PAYMENT'
    }], { session });

    cart.items = [];
    await cart.save({ session });

    await session.commitTransaction();

    const populatedOrder = await Order.findById(order[0]._id)
      .populate('items.productId', 'name price description');

    orderExpiryService.scheduleOrderExpiry(order[0]._id.toString(), 15 * 60 * 1000);

    res.status(201).json({
      success: true,
      data: populatedOrder
    });
  } catch (error) {
    await session.abortTransaction();
    console.error('Checkout error:', error);
    next(error);
  } finally {
    session.endSession();
  }
};

const processPayment = async (req, res, next) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();

    const order = await Order.findById(req.params.id).session(session);
    
    if (!order) {
      await session.abortTransaction();
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    if (order.status !== 'PENDING_PAYMENT') {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: `Order cannot be paid. Current status: ${order.status}`
      });
    }

    if (order.userId.toString() !== req.user._id.toString()) {
      await session.abortTransaction();
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this order'
      });
    }

    const payment = await Payment.create([{
      orderId: order._id,
      transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      amount: order.totalAmount,
      status: 'SUCCESS'
    }], { session });

    for (const item of order.items) {
      await Product.commitReservedStock(item.productId, item.quantity, session);
    }

    order.status = 'PAID';
    await order.save({ session });

    await session.commitTransaction();

    orderExpiryService.cancelOrderExpiry(order._id.toString());

    await emailQueueService.addConfirmationEmail(
      order._id.toString(),
      req.user.email,
      order.totalAmount,
    );

    res.json({
      success: true,
      data: {
        order,
        payment: payment[0]
      }
    });
  } catch (error) {
    await session.abortTransaction();
    console.error('Payment processing error:', error);
    next(error);
  } finally {
    session.endSession();
  }
};

const getOrders = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;

    const orders = await Order.find({ userId: req.user._id })
      .populate('items.productId')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments({ userId: req.user._id });

    res.json({
      success: true,
      data: orders,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

const getOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id).populate('items.productId');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this order'
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  checkout,
  processPayment,
  getOrders,
  getOrder
};