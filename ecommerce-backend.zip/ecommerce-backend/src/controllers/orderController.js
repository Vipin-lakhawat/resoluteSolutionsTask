// const Order = require('../models/Order');
// const Cart = require('../models/Cart');
// const Product = require('../models/Product');
// const Payment = require('../models/Payment');
// const emailQueueService = require('../services/emailQueue');
// const orderExpiryService = require('../services/orderExpiryService');

// const checkout = async (req, res, next) => {
//   const session = await Order.startSession();
  
//   try {
//     session.startTransaction();

//     // Get user's cart
//     const cart = await Cart.findOne({ userId: req.user._id }).populate('items.productId').session(session);
    
//     if (!cart || cart.items.length === 0) {
//       await session.abortTransaction();
//       return res.status(400).json({
//         success: false,
//         message: 'Cart is empty'
//       });
//     }

//     // Prepare order items and reserve stock
//     const orderItems = [];
    
//     for (const cartItem of cart.items) {
//       const product = cartItem.productId;
      
//       // Reserve stock
//       await product.reserveStock(cartItem.quantity);
      
//       orderItems.push({
//         productId: product._id,
//         quantity: cartItem.quantity,
//         priceAtPurchase: product.price
//       });
//     }

//     // Create order
//     const order = await Order.create([{
//       userId: req.user._id,
//       items: orderItems,
//       status: 'PENDING_PAYMENT'
//     }], { session });

//     // Clear cart
//     cart.items = [];
//     await cart.save({ session });

//     await session.commitTransaction();

//     // Schedule order expiry
//     orderExpiryService.scheduleOrderExpiry(order[0]._id.toString());

//     res.status(201).json({
//       success: true,
//       data: order[0]
//     });
//   } catch (error) {
//     await session.abortTransaction();
//     next(error);
//   } finally {
//     session.endSession();
//   }
// };

// const processPayment = async (req, res, next) => {
//   const session = await Order.startSession();
  
//   try {
//     session.startTransaction();

//     const order = await Order.findById(req.params.id).session(session);
    
//     if (!order) {
//       await session.abortTransaction();
//       return res.status(404).json({
//         success: false,
//         message: 'Order not found'
//       });
//     }

//     if (order.status !== 'PENDING_PAYMENT') {
//       await session.abortTransaction();
//       return res.status(400).json({
//         success: false,
//         message: `Order cannot be paid. Current status: ${order.status}`
//       });
//     }

//     // Check if user owns the order
//     if (order.userId.toString() !== req.user._id.toString()) {
//       await session.abortTransaction();
//       return res.status(403).json({
//         success: false,
//         message: 'Not authorized to access this order'
//       });
//     }

//     // Mock payment processing - always successful for demo
//     const payment = await Payment.create([{
//       orderId: order._id,
//       transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
//       amount: order.totalAmount,
//       status: 'SUCCESS'
//     }], { session });

//     // Commit reserved stock
//     for (const item of order.items) {
//       const product = await Product.findById(item.productId).session(session);
//       if (product) {
//         await product.commitReservedStock(item.quantity);
//       }
//     }

//     // Update order status
//     order.status = 'PAID';
//     await order.save({ session });

//     await session.commitTransaction();

//     // Cancel order expiry
//     orderExpiryService.cancelOrderExpiry(order._id.toString());

//     // Queue confirmation email
//     await emailQueueService.addConfirmationEmail(
//       order._id.toString(),
//       req.user.email
//     );

//     res.json({
//       success: true,
//       data: {
//         order,
//         payment: payment[0]
//       }
//     });
//   } catch (error) {
//     await session.abortTransaction();
//     next(error);
//   } finally {
//     session.endSession();
//   }
// };

// const getOrders = async (req, res, next) => {
//   try {
//     const { page = 1, limit = 10 } = req.query;

//     const orders = await Order.find({ userId: req.user._id })
//       .populate('items.productId')
//       .sort({ createdAt: -1 })
//       .limit(limit * 1)
//       .skip((page - 1) * limit);

//     const total = await Order.countDocuments({ userId: req.user._id });

//     res.json({
//       success: true,
//       data: orders,
//       pagination: {
//         page: parseInt(page),
//         limit: parseInt(limit),
//         total,
//         pages: Math.ceil(total / limit)
//       }
//     });
//   } catch (error) {
//     next(error);
//   }
// };

// const getOrder = async (req, res, next) => {
//   try {
//     const order = await Order.findById(req.params.id).populate('items.productId');
    
//     if (!order) {
//       return res.status(404).json({
//         success: false,
//         message: 'Order not found'
//       });
//     }

//     // Check if user owns the order
//     if (order.userId.toString() !== req.user._id.toString()) {
//       return res.status(403).json({
//         success: false,
//         message: 'Not authorized to access this order'
//       });
//     }

//     res.json({
//       success: true,
//       data: order
//     });
//   } catch (error) {
//     next(error);
//   }
// };

// module.exports = {
//   checkout,
//   processPayment,
//   getOrders,
//   getOrder
// };


const mongoose = require('mongoose'); // Add this import
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const Payment = require('../models/Payment');
const emailQueueService = require('../services/emailQueue');
const orderExpiryService = require('../services/orderExpiryService');

const checkout = async (req, res, next) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();

    // Get user's cart with product details
    const cart = await Cart.findOne({ userId: req.user._id })
      .populate('items.productId')
      .session(session);
    
    if (!cart || cart.items.length === 0) {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: 'Cart is empty'
      });
    }

    // Prepare order items and reserve stock
    const orderItems = [];
    
    for (const cartItem of cart.items) {
      const product = cartItem.productId;
      
      if (!product) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: `Product not found for item: ${cartItem.productId}`
        });
      }
      
      // Check stock availability first
      if (product.availableStock < cartItem.quantity) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for ${product.name}. Available: ${product.availableStock}, Requested: ${cartItem.quantity}`
        });
      }

      // Reserve stock using static method with session
      await Product.reserveStock(product._id, cartItem.quantity, session);
      
      orderItems.push({
        productId: product._id,
        quantity: cartItem.quantity,
        priceAtPurchase: product.price
      });
    }

    // Create order
    const order = await Order.create([{
      userId: req.user._id,
      items: orderItems,
      status: 'PENDING_PAYMENT'
    }], { session });

    // Clear cart
    cart.items = [];
    await cart.save({ session });

    await session.commitTransaction();

    // Populate the order with product details for response
    const populatedOrder = await Order.findById(order[0]._id)
      .populate('items.productId', 'name price description');

    // Schedule order expiry (15 minutes)
    orderExpiryService.scheduleOrderExpiry(order[0]._id.toString(), 15 * 60 * 1000);

    res.status(201).json({
      success: true,
      data: populatedOrder
    });
  } catch (error) {
    await session.abortTransaction();
    console.error('Checkout error:', error);
    next(error);
  } finally {
    session.endSession();
  }
};

const processPayment = async (req, res, next) => {
  const session = await mongoose.startSession();
  
  try {
    session.startTransaction();

    const order = await Order.findById(req.params.id).session(session);
    
    if (!order) {
      await session.abortTransaction();
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    if (order.status !== 'PENDING_PAYMENT') {
      await session.abortTransaction();
      return res.status(400).json({
        success: false,
        message: `Order cannot be paid. Current status: ${order.status}`
      });
    }

    // Check if user owns the order
    if (order.userId.toString() !== req.user._id.toString()) {
      await session.abortTransaction();
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this order'
      });
    }

    // Mock payment processing - always successful for demo
    const payment = await Payment.create([{
      orderId: order._id,
      transactionId: `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      amount: order.totalAmount,
      status: 'SUCCESS'
    }], { session });

    // Commit reserved stock using static methods
    for (const item of order.items) {
      await Product.commitReservedStock(item.productId, item.quantity, session);
    }

    // Update order status
    order.status = 'PAID';
    await order.save({ session });

    await session.commitTransaction();

    // Cancel order expiry
    orderExpiryService.cancelOrderExpiry(order._id.toString());

    // Queue confirmation email
    await emailQueueService.addConfirmationEmail(
      order._id.toString(),
      req.user.email
    );

    res.json({
      success: true,
      data: {
        order,
        payment: payment[0]
      }
    });
  } catch (error) {
    await session.abortTransaction();
    console.error('Payment processing error:', error);
    next(error);
  } finally {
    session.endSession();
  }
};

const getOrders = async (req, res, next) => {
  try {
    const { page = 1, limit = 10 } = req.query;

    const orders = await Order.find({ userId: req.user._id })
      .populate('items.productId')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments({ userId: req.user._id });

    res.json({
      success: true,
      data: orders,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

const getOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id).populate('items.productId');
    
    if (!order) {
      return res.status(404).json({
        success: false,
        message: 'Order not found'
      });
    }

    // Check if user owns the order
    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: 'Not authorized to access this order'
      });
    }

    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  checkout,
  processPayment,
  getOrders,
  getOrder
};