const Order = require('../models/Order');
const Product = require('../models/Product');
const orderExpiryService = require('../services/orderExpiryService');
const { orderStatusValidation, validate } = require('../utils/validation');

const getOrders = async (req, res, next) => {
  try {
    const { page = 1, limit = 10, status } = req.query;

    let query = {};
    if (status) {
      query.status = status;
    }

    const orders = await Order.find(query)
      .populate('userId', 'name email')
      .populate('items.productId')
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Order.countDocuments(query);

    res.json({
      success: true,
      data: orders,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
};

const updateOrderStatus = [
  validate(orderStatusValidation),
  async (req, res, next) => {
    try {
      const order = await Order.findByIdAndUpdate(
        req.params.id,
        { status: req.body.status },
        { new: true, runValidators: true }
      ).populate('userId', 'name email').populate('items.productId');

      if (!order) {
        return res.status(404).json({
          success: false,
          message: 'Order not found'
        });
      }

      res.json({
        success: true,
        data: order
      });
    } catch (error) {
      next(error);
    }
  }
];

const getProductStock = async (req, res, next) => {
  try {
    const products = await Product.find({});
    
    const stockInfo = products.map(product => ({
      id: product._id,
      name: product.name,
      availableStock: product.availableStock,
      reservedStock: product.reservedStock,
      totalStock: product.totalStock
    }));

    res.json({
      success: true,
      data: stockInfo
    });
  } catch (error) {
    next(error);
  }
};

const getPendingExpiryOrders = async (req, res, next) => {
  try {
    const pendingOrders = orderExpiryService.getPendingOrders();
    
    res.json({
      success: true,
      data: pendingOrders
    });
  } catch (error) {
    next(error);
  }
};

// Manual expiry trigger for testing
const triggerOrderExpiry = async (req, res, next) => {
  try {
    const { orderId } = req.params;
    
    await orderExpiryService.manuallyTriggerExpiry(orderId);
    
    res.json({
      success: true,
      message: `Manually triggered expiry for order ${orderId}`
    });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  getOrders,
  updateOrderStatus,
  getProductStock,
  getPendingExpiryOrders,
  triggerOrderExpiry
};