const express = require('express');
const { protect } = require('../middleware/auth');
const {
  getCart,
  addToCart,
  removeFromCart
} = require('../controllers/cartController');

const router = express.Router();

router.use(protect);

router.get('/', getCart);
router.post('/items', addToCart);
router.delete('/items/:productId', removeFromCart);

module.exports = router;