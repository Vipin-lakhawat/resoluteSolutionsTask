const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  getOrders,
  updateOrderStatus
} = require('../controllers/adminController');

const router = express.Router();

router.use(protect);
router.use(authorize('ADMIN'));

router.get('/orders', getOrders);
router.patch('/orders/:id/status', updateOrderStatus);

module.exports = router;