const express = require('express');
const { protect } = require('../middleware/auth');
const {
  checkout,
  processPayment,
  getOrders,
  getOrder,
  paymentFailed,
} = require('../controllers/orderController');

const router = express.Router();

router.use(protect);

router.post('/checkout', checkout);
router.post('/:id/pay', processPayment);
router.post('/:id/payment-failed', paymentFailed); 
router.get('/', getOrders);
router.get('/:id', getOrder);

module.exports = router;