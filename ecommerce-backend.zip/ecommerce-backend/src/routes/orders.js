const express = require('express');
const { protect } = require('../middleware/auth');
const {
  checkout,
  processPayment,
  getOrders,
  getOrder
} = require('../controllers/orderController');

const router = express.Router();

router.use(protect);

router.post('/checkout', checkout);
router.post('/:id/pay', processPayment);
router.get('/', getOrders);
router.get('/:id', getOrder);

module.exports = router;