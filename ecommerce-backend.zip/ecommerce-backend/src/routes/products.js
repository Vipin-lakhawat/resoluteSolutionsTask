const express = require('express');
const { protect, authorize } = require('../middleware/auth');
const {
  createProduct,
  updateProduct,
  deleteProduct,
  getProducts
} = require('../controllers/productController');

const router = express.Router();

router.get('/', getProducts);
router.post('/', protect, authorize('ADMIN'), createProduct);
router.put('/:id', protect, authorize('ADMIN'), updateProduct);
router.delete('/:id', protect, authorize('ADMIN'), deleteProduct);

module.exports = router;