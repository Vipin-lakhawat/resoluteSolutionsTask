const mongoose = require('mongoose');
const Order = require('../models/Order');
const Product = require('../models/Product');

class OrderExpiryService {
  constructor() {
    this.pendingOrders = new Map();
    this.timeout = 15 * 60 * 1000; // 15 minutes for testing
  }

  scheduleOrderExpiry(orderId) {
    console.log(`⏰ Scheduling order expiry for ${orderId} in ${this.timeout/1000} seconds`);
    
    const timer = setTimeout(async () => {
      await this.handleOrderExpiry(orderId);
    }, this.timeout);

    this.pendingOrders.set(orderId, {
      timer,
      scheduledAt: new Date(),
      expiresAt: new Date(Date.now() + this.timeout)
    });

  }

  async handleOrderExpiry(orderId) {
    
    const session = await mongoose.startSession();
    
    try {
      session.startTransaction();

      const order = await Order.findById(orderId).session(session);
      
      if (order && order.status === 'PENDING_PAYMENT') {
        
        for (const item of order.items) {
          
          const productBefore = await Product.findById(item.productId);
          
          await Product.releaseReservedStock(item.productId, item.quantity, session);
          
          const productAfter = await Product.findById(item.productId);
        }

        // Update order status to CANCELLED
        order.status = 'CANCELLED';
        await order.save({ session });

        await session.commitTransaction();
        
        this.pendingOrders.delete(orderId);
      } else {
        await session.abortTransaction();
      }
    } catch (error) {
      await session.abortTransaction();
    } finally {
      session.endSession();
    }
  }

  cancelOrderExpiry(orderId) {
    const orderData = this.pendingOrders.get(orderId);
    if (orderData) {
      clearTimeout(orderData.timer);
      this.pendingOrders.delete(orderId);
    }
  }

  getPendingOrders() {
    const pending = Array.from(this.pendingOrders.entries()).map(([orderId, data]) => ({
      orderId,
      scheduledAt: data.scheduledAt,
      expiresAt: data.expiresAt,
      timeRemaining: Math.max(0, data.expiresAt - Date.now())
    }));
    
    return pending;
  }

  async manuallyTriggerExpiry(orderId) {
    await this.handleOrderExpiry(orderId);
  }
}

module.exports = new OrderExpiryService();