const mongoose = require('mongoose');
const Order = require('../models/Order');
const Product = require('../models/Product');

class OrderExpiryService {
  constructor() {
    this.pendingOrders = new Map();
  }

  scheduleOrderExpiry(orderId, timeout = 15 * 60 * 1000) {
    const timer = setTimeout(async () => {
      await this.handleOrderExpiry(orderId);
    }, timeout);

    this.pendingOrders.set(orderId, timer);
  }

  async handleOrderExpiry(orderId) {
    const session = await mongoose.startSession();
    
    try {
      session.startTransaction();

      const order = await Order.findById(orderId).session(session);
      
      if (order && order.status === 'PENDING_PAYMENT') {
        for (const item of order.items) {
          await Product.releaseReservedStock(item.productId, item.quantity, session);
        }

        order.status = 'CANCELLED';
        await order.save({ session });

        await session.commitTransaction();
        console.log(`Order ${orderId} cancelled due to payment timeout`);
        
        this.pendingOrders.delete(orderId);
      } else {
        await session.abortTransaction();
      }
    } catch (error) {
      await session.abortTransaction();
      console.error(`Error handling order expiry for ${orderId}:`, error);
    } finally {
      session.endSession();
    }
  }

  cancelOrderExpiry(orderId) {
    const timer = this.pendingOrders.get(orderId);
    if (timer) {
      clearTimeout(timer);
      this.pendingOrders.delete(orderId);
    }
  }
}

module.exports = new OrderExpiryService();