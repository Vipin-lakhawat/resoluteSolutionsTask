const Queue = require('bull');
const { getRedisStatus } = require('../config/redis');

class EmailQueueService {
  constructor() {
    this.isQueueEnabled = false;
    this.emailQueue = null;
    
    this.initQueue();
  }

  initQueue() {
    try {
      this.emailQueue = new Queue('email confirmation', {
        redis: {
          host: 'localhost',
          port: 6379
        }
      });

      this.setupProcessor();
      this.isQueueEnabled = true;
      console.log('Email queue initialized');
    } catch (error) {
      console.log('Email queue disabled (Redis not available):', error.message);
      this.isQueueEnabled = false;
    }
  }

  setupProcessor() {
    if (!this.isQueueEnabled) return;

    this.emailQueue.process('send-confirmation', async (job) => {
      const { orderId, userEmail, userName, orderTotal } = job.data;
      
      console.log(`[QUEUE] Sending confirmation email for order ${orderId} to ${userEmail}`);
      console.log(`[QUEUE] Customer: ${userName}, Amount: $${orderTotal}`);
      
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      console.log(`[QUEUE] Confirmation email sent for order ${orderId}`);
      return { success: true, orderId, userEmail, userName, orderTotal };
    });
  }

  async addConfirmationEmail(orderId, userEmail, userName = 'Customer', orderTotal = 0) {
    if (!this.isQueueEnabled) {
      console.log(`[FALLBACK] Email notification for order ${orderId} to ${userEmail}`);
      return { success: true, skipped: true, message: 'Queue disabled' };
    }

    return await this.emailQueue.add('send-confirmation', {
      orderId,
      userEmail,
      userName,
      orderTotal
    }, {
      delay: 1000,
      attempts: 3,
      backoff: 'exponential'
    });
  }
}

module.exports = new EmailQueueService();