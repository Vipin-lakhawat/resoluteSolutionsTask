const Queue = require('bull');
const nodemailer = require('nodemailer');

class EmailQueueService {
  constructor() {
    this.emailQueue = new Queue('email confirmation', {
      redis: {
        host: process.env.REDIS_HOST || '127.0.0.1',
        port: process.env.REDIS_PORT || 6379,
      },
    });
    this.transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      secure: process.env.EMAIL_SECURE === 'true',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });

    this.setupProcessor();
  }

  setupProcessor() {
    this.emailQueue.process('send-confirmation', async (job) => {
      const { orderId, userEmail, userName, totalAmount  } = job.data;

      try {
        const mailOptions = {
          from: process.env.EMAIL_FROM || `"E-Commerce Store" <${process.env.EMAIL_USER}>`,
          to: userEmail,
          subject: `Order Confirmation - #${orderId}`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #333;">Order Confirmation</h2>
              <p>Hello ${userName},</p>
              <p>Thank you for your order! Your order has been confirmed.</p>

              <div style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <h3>Order Details:</h3>
                <p><strong>Order ID:</strong> ${orderId}</p>
                <p><strong>Total Amount:</strong> $${totalAmount }</p>
                <p><strong>Order Date:</strong> ${new Date().toLocaleDateString()}</p>
              </div>

              <p>We'll send you another email when your order ships.</p>
              <p>Thank you for shopping with us!</p>

              <hr style="margin: 30px 0;">
              <p style="color: #666; font-size: 12px;">
                If you have any questions, contact us at ${process.env.SUPPORT_EMAIL || 'support@ecommerce.com'}
              </p>
            </div>
          `,
        };


        // Send actual email
        const info = await this.transporter.sendMail(mailOptions);

        console.log(`✅ Email sent to ${userEmail} for order ${orderId}`);
        console.log(`📩 Message ID: ${info.messageId}`);

        return {
          success: true,
          orderId,
          userEmail,
          messageId: info.messageId,
        };
      } catch (error) {
        console.error(`❌ Failed to send email for order ${orderId}:`, error);
        throw error; // triggers retry mechanism
      }
    });
  }

  // Function to add job to queue
  async addConfirmationEmail(orderId, userEmail, userName = 'Customer', totalAmount) {
    return await this.emailQueue.add(
      'send-confirmation',
      { orderId, userEmail, userName, totalAmount },
      {
        delay: 1000,
        attempts: 3,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: true,
        removeOnFail: false,
      }
    );
  }

  // Get current queue stats
  async getQueueStats() {
    const [waiting, active, completed, failed, delayed] = await Promise.all([
      this.emailQueue.getWaiting(),
      this.emailQueue.getActive(),
      this.emailQueue.getCompleted(),
      this.emailQueue.getFailed(),
      this.emailQueue.getDelayed(),
    ]);

    return {
      waiting: waiting.length,
      active: active.length,
      completed: completed.length,
      failed: failed.length,
      delayed: delayed.length,
    };
  }
}

module.exports = new EmailQueueService();
