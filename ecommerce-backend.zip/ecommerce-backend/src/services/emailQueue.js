const Queue = require('bull');
const { getRedisClient } = require('../config/redis');

class EmailQueueService {
  constructor() {
    this.emailQueue = new Queue('email confirmation', {
      redis: {
        host: 'localhost',
        port: 6379
      }
    });

    this.setupProcessor();
  }

  setupProcessor() {
    this.emailQueue.process('send-confirmation', async (job) => {
      const { orderId, userEmail } = job.data;
      
      // Simulate email sending
      console.log(`Sending confirmation email for order ${orderId} to ${userEmail}`);
      
      // In a real application, you would integrate with an email service like SendGrid, Mailgun, etc.
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate email sending delay
      
      console.log(`Confirmation email sent for order ${orderId}`);
      return { success: true, orderId, userEmail };
    });
  }

  async addConfirmationEmail(orderId, userEmail) {
    return await this.emailQueue.add('send-confirmation', {
      orderId,
      userEmail
    }, {
      delay: 1000, // 1 second delay
      attempts: 3,
      backoff: 'exponential'
    });
  }
}

module.exports = new EmailQueueService();