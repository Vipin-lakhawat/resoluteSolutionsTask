const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  availableStock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: [0, 'Stock cannot be negative'],
    default: 0
  },
  reservedStock: {
    type: Number,
    default: 0,
    min: 0
  }
}, {
  timestamps: true
});

productSchema.virtual('totalStock').get(function() {
  return this.availableStock + this.reservedStock;
});

productSchema.statics.reserveStock = async function(productId, quantity, session = null) {
  
  const updateData = {
    $inc: {
      availableStock: -quantity,
      reservedStock: quantity
    }
  };
  
  console.log('📝 Update data:', updateData);
  
  const options = { 
    new: true,
    session: session
  };
  
  const result = await this.findByIdAndUpdate(productId, updateData, options);
  
  if (!result) {
    throw new Error('Product not found');
  }

  console.log(`✅ reserveStock result - Available: ${result.availableStock}, Reserved: ${result.reservedStock}`);
  
  return result;
};

productSchema.statics.releaseReservedStock = async function(productId, quantity, session = null) {
  
  const updateData = {
    $inc: {
      reservedStock: -quantity,
      availableStock: quantity
    }
  };
  
  console.log('📝 Update data:', updateData);
  
  const options = { 
    new: true,
    session: session
  };
  
  const result = await this.findByIdAndUpdate(productId, updateData, options);
  
  if (!result) {
    throw new Error('Product not found');
  }
  
  console.log(`✅ releaseReservedStock result - Available: ${result.availableStock}, Reserved: ${result.reservedStock}`);
  
  return result;
};

productSchema.statics.commitReservedStock = async function(productId, quantity, session = null) {
  
  const updateData = {
    $inc: {
      reservedStock: -quantity
    }
  };
  
  console.log('📝 Update data:', updateData);
  
  const options = { 
    new: true,
    session: session
  };
  
  const result = await this.findByIdAndUpdate(productId, updateData, options);
  
  if (!result) {
    throw new Error('Product not found');
  }
  
  
  return result;
};

module.exports = mongoose.model('Product', productSchema);