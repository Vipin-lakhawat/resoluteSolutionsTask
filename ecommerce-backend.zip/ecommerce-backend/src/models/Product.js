// const mongoose = require('mongoose');

// const productSchema = new mongoose.Schema({
//   name: {
//     type: String,
//     required: [true, 'Product name is required'],
//     trim: true
//   },
//   price: {
//     type: Number,
//     required: [true, 'Product price is required'],
//     min: [0, 'Price cannot be negative']
//   },
//   description: {
//     type: String,
//     required: [true, 'Product description is required']
//   },
//   availableStock: {
//     type: Number,
//     required: [true, 'Stock quantity is required'],
//     min: [0, 'Stock cannot be negative'],
//     default: 0
//   },
//   reservedStock: {
//     type: Number,
//     default: 0,
//     min: 0
//   }
// }, {
//   timestamps: true
// });

// // Virtual for total stock
// productSchema.virtual('totalStock').get(function() {
//   return this.availableStock + this.reservedStock;
// });

// // Method to reserve stock
// productSchema.methods.reserveStock = async function(quantity) {
//   if (this.availableStock < quantity) {
//     throw new Error(`Insufficient stock. Available: ${this.availableStock}, Requested: ${quantity}`);
//   }
  
//   this.availableStock -= quantity;
//   this.reservedStock += quantity;
//   return await this.save();
// };

// // Method to release reserved stock
// productSchema.methods.releaseReservedStock = async function(quantity) {
//   if (this.reservedStock < quantity) {
//     throw new Error(`Insufficient reserved stock. Reserved: ${this.reservedStock}, Requested to release: ${quantity}`);
//   }
  
//   this.reservedStock -= quantity;
//   this.availableStock += quantity;
//   return await this.save();
// };

// // Method to commit reserved stock (after payment)
// productSchema.methods.commitReservedStock = async function(quantity) {
//   if (this.reservedStock < quantity) {
//     throw new Error(`Insufficient reserved stock to commit. Reserved: ${this.reservedStock}`);
//   }
  
//   this.reservedStock -= quantity;
//   return await this.save();
// };

// module.exports = mongoose.model('Product', productSchema);


const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  availableStock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: [0, 'Stock cannot be negative'],
    default: 0
  },
  reservedStock: {
    type: Number,
    default: 0,
    min: 0
  }
}, {
  timestamps: true
});

// Virtual for total stock
productSchema.virtual('totalStock').get(function() {
  return this.availableStock + this.reservedStock;
});

// Static method to reserve stock
productSchema.statics.reserveStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.availableStock < quantity) {
    throw new Error(`Insufficient stock. Available: ${product.availableStock}, Requested: ${quantity}`);
  }
  
  // Update stock directly
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        availableStock: -quantity,
        reservedStock: quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

// Static method to release reserved stock
productSchema.statics.releaseReservedStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock. Reserved: ${product.reservedStock}, Requested to release: ${quantity}`);
  }
  
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        reservedStock: -quantity,
        availableStock: quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

// Static method to commit reserved stock (after payment)
productSchema.statics.commitReservedStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock to commit. Reserved: ${product.reservedStock}`);
  }
  
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        reservedStock: -quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

module.exports = mongoose.model('Product', productSchema);