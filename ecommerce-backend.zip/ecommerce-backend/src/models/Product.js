const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative']
  },
  description: {
    type: String,
    required: [true, 'Product description is required']
  },
  availableStock: {
    type: Number,
    required: [true, 'Stock quantity is required'],
    min: [0, 'Stock cannot be negative'],
    default: 0
  },
  reservedStock: {
    type: Number,
    default: 0,
    min: 0
  }
}, {
  timestamps: true
});

productSchema.virtual('totalStock').get(function() {
  return this.availableStock + this.reservedStock;
});

productSchema.statics.reserveStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.availableStock < quantity) {
    throw new Error(`Insufficient stock. Available: ${product.availableStock}, Requested: ${quantity}`);
  }
  
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        availableStock: -quantity,
        reservedStock: quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

productSchema.statics.releaseReservedStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock. Reserved: ${product.reservedStock}, Requested to release: ${quantity}`);
  }
  
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        reservedStock: -quantity,
        availableStock: quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

productSchema.statics.commitReservedStock = async function(productId, quantity, session = null) {
  const product = await this.findById(productId);
  
  if (!product) {
    throw new Error('Product not found');
  }
  
  if (product.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock to commit. Reserved: ${product.reservedStock}`);
  }
  
  const result = await this.findByIdAndUpdate(
    productId,
    {
      $inc: {
        reservedStock: -quantity
      }
    },
    { 
      new: true,
      session: session
    }
  );
  
  return result;
};

module.exports = mongoose.model('Product', productSchema);