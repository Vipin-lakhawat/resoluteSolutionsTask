const { initRedis, getRedisClient } = require('../utils/redisClient');

initRedis().catch((err) => console.error('⚠️ Redis initialization failed:', err));

module.exports = { getRedisClient, initRedis };
