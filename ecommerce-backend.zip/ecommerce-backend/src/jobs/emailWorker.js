// jobs/emailWorker.js
const emailQueueService = require('../services/emailQueue');

console.log('📨 Email worker started and listening for queued jobs...');
