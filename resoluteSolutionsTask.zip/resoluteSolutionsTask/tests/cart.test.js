const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../src/app');
const User = require('../src/models/User');
const Product = require('../src/models/Product');
const Cart = require('../src/models/Cart');

describe('Cart API', () => {
  let userToken;
  let regularUser;
  let product1, product2, product3;

  beforeAll(async () => {
    regularUser = await User.create({
      name: 'Cart User',
      email: 'cartuser@test.com',
      password: 'password123',
      role: 'USER'
    });

    const userLogin = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'cartuser@test.com',
        password: 'password123'
      });
    userToken = userLogin.body.token;

    product1 = await Product.create({
      name: 'Cart Product 1',
      price: 15.99,
      description: 'First product for cart testing',
      availableStock: 50,
      category: 'Electronics'
    });

    product2 = await Product.create({
      name: 'Cart Product 2',
      price: 25.50,
      description: 'Second product for cart testing',
      availableStock: 30,
      category: 'Books'
    });

    product3 = await Product.create({
      name: 'Cart Product 3',
      price: 8.99,
      description: 'Third product for cart testing',
      availableStock: 10, 
      category: 'Home'
    });
  });

  afterAll(async () => {
    await User.deleteMany({});
    await Product.deleteMany({});
    await Cart.deleteMany({});
  });

  beforeEach(async () => {
    await Cart.deleteMany({});
  });

  describe('GET /api/cart', () => {
    it('should get empty cart for new user', async () => {
      const response = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.items).toHaveLength(0);
      expect(response.body.totalAmount).toBe(0);
      expect(response.body.totalItems).toBe(0);
    });

    it('should get cart with items', async () => {
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product1._id, quantity: 2 },
          { productId: product2._id, quantity: 1 }
        ]
      });
      await cart.save();

      const response = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.items).toHaveLength(2);
      expect(response.body.totalItems).toBe(3);
      expect(response.body.totalAmount).toBe(2 * 15.99 + 25.50);
    });

    it('should not get cart without authentication', async () => {
      const response = await request(app)
        .get('/api/cart')
        .expect(401);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('POST /api/cart/items', () => {
    it('should add item to cart', async () => {
      const cartItem = {
        productId: product1._id,
        quantity: 3
      };

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send(cartItem)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Item added to cart successfully');
      expect(response.body.cart.items).toHaveLength(1);
      expect(response.body.cart.items[0].quantity).toBe(3);
    });

    it('should update quantity when adding existing product', async () => {
      await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ productId: product1._id, quantity: 2 });

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ productId: product1._id, quantity: 3 })
        .expect(200);

      expect(response.body.cart.items).toHaveLength(1);
      expect(response.body.cart.items[0].quantity).toBe(5);
    });

    it('should not add item with insufficient stock', async () => {
      const cartItem = {
        productId: product3._id, 
        quantity: 15 
      };

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send(cartItem)
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('Insufficient stock');
    });

    it('should not add non-existent product', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();
      const cartItem = {
        productId: nonExistentId,
        quantity: 1
      };

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send(cartItem)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Product not found');
    });

    it('should validate cart item data', async () => {
      const invalidItem = {
        productId: 'invalid-id',
        quantity: 0 
      };

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send(invalidItem)
        .expect(400);

      expect(response.body).toHaveProperty('error');
    });

    it('should not add inactive product', async () => {
  
      const inactiveProduct = await Product.create({
        name: 'Inactive Product',
        price: 9.99,
        description: 'This product is inactive',
        availableStock: 5,
        isActive: false
      });

      const cartItem = {
        productId: inactiveProduct._id,
        quantity: 1
      };

      const response = await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send(cartItem)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Product not found');
    });
  });

  describe('PUT /api/cart/items/:productId', () => {
    beforeEach(async () => {
   
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product1._id, quantity: 2 },
          { productId: product2._id, quantity: 1 }
        ]
      });
      await cart.save();
    });

    it('should update cart item quantity', async () => {
      const response = await request(app)
        .put(`/api/cart/items/${product1._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ quantity: 5 })
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Cart item updated successfully');
      expect(response.body.cart.items.find(item => 
        item.productId._id === product1._id.toString()
      ).quantity).toBe(5);
    });

    it('should remove item when quantity set to 0', async () => {
      const response = await request(app)
        .put(`/api/cart/items/${product1._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ quantity: 0 })
        .expect(200);

      expect(response.body.cart.items).toHaveLength(1);
      expect(response.body.cart.items.find(item => 
        item.productId._id === product1._id.toString()
      )).toBeUndefined();
    });

    it('should not update with insufficient stock', async () => {
      const response = await request(app)
        .put(`/api/cart/items/${product3._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ quantity: 15 }) 
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('Insufficient stock');
    });

    it('should return 404 when updating non-existent cart item', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();

      const response = await request(app)
        .put(`/api/cart/items/${nonExistentId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ quantity: 5 })
        .expect(400);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('DELETE /api/cart/items/:productId', () => {
    beforeEach(async () => {
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product1._id, quantity: 2 },
          { productId: product2._id, quantity: 1 }
        ]
      });
      await cart.save();
    });

    it('should remove item from cart', async () => {
      const response = await request(app)
        .delete(`/api/cart/items/${product1._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Item removed from cart successfully');
      expect(response.body.cart.items).toHaveLength(1);
      expect(response.body.cart.items.find(item => 
        item.productId._id === product1._id.toString()
      )).toBeUndefined();
    });

    it('should return 404 when cart not found', async () => {
      const otherUser = await User.create({
        name: 'Other User',
        email: 'other@test.com',
        password: 'password123'
      });

      const otherUserLogin = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'other@test.com',
          password: 'password123'
        });
      const otherUserToken = otherUserLogin.body.token;

      const response = await request(app)
        .delete(`/api/cart/items/${product1._id}`)
        .set('Authorization', `Bearer ${otherUserToken}`)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Cart not found');
    });

    it('should handle removing non-existent item gracefully', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();

      const response = await request(app)
        .delete(`/api/cart/items/${nonExistentId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200); 

      expect(response.body).toHaveProperty('message', 'Item removed from cart successfully');
    });
  });

  describe('DELETE /api/cart', () => {
    beforeEach(async () => {
    
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product1._id, quantity: 2 },
          { productId: product2._id, quantity: 1 }
        ]
      });
      await cart.save();
    });

    it('should clear entire cart', async () => {
      const response = await request(app)
        .delete('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Cart cleared successfully');

      
      const cartResponse = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(cartResponse.body.items).toHaveLength(0);
      expect(cartResponse.body.totalItems).toBe(0);
    });

    it('should handle clearing empty cart', async () => {
    
      await request(app)
        .delete('/api/cart')
        .set('Authorization', `Bearer ${userToken}`);

    
      const response = await request(app)
        .delete('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(404); 

      expect(response.body).toHaveProperty('error', 'Cart not found');
    });
  });

  describe('Cart stock validation', () => {
    it('should show stock availability in cart response', async () => {
    
      await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ productId: product1._id, quantity: 5 });

      const response = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      const cartItem = response.body.items[0];
      expect(cartItem.product).toHaveProperty('canFulfill', true);
      expect(cartItem.product.availableStock).toBe(50);
    });

    it('should show cannot fulfill when quantity exceeds stock', async () => {
     
      await request(app)
        .post('/api/cart/items')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ productId: product3._id, quantity: 15 }); 

      const response = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      const cartItem = response.body.items.find(item => 
        item.productId === product3._id.toString()
      );
      expect(cartItem.product.canFulfill).toBe(false);
    });
  });
});