const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../src/app');
const User = require('../src/models/User');
const Product = require('../src/models/Product');
const Cart = require('../src/models/Cart');
const Order = require('../src/models/Order');
const Payment = require('../src/models/Payment');

describe('Orders API', () => {
  let userToken;
  let adminToken;
  let regularUser;
  let adminUser;
  let product1, product2, product3;

  beforeAll(async () => {
    regularUser = await User.create({
      name: 'Order User',
      email: 'orderuser@test.com',
      password: 'password123',
      role: 'USER'
    });

    adminUser = await User.create({
      name: 'Order Admin',
      email: 'orderadmin@test.com',
      password: 'password123',
      role: 'ADMIN'
    });

    const userLogin = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'orderuser@test.com',
        password: 'password123'
      });
    userToken = userLogin.body.token;

    const adminLogin = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'orderadmin@test.com',
        password: 'password123'
      });
    adminToken = adminLogin.body.token;

    product1 = await Product.create({
      name: 'Order Product 1',
      price: 19.99,
      description: 'First product for order testing',
      availableStock: 100,
      category: 'Electronics'
    });

    product2 = await Product.create({
      name: 'Order Product 2',
      price: 29.50,
      description: 'Second product for order testing',
      availableStock: 50,
      category: 'Books'
    });

    product3 = await Product.create({
      name: 'Order Product 3',
      price: 7.99,
      description: 'Third product for order testing',
      availableStock: 25,
      category: 'Home'
    });
  });

  afterAll(async () => {
    await User.deleteMany({});
    await Product.deleteMany({});
    await Cart.deleteMany({});
    await Order.deleteMany({});
    await Payment.deleteMany({});
  });

  beforeEach(async () => {
    await Cart.deleteMany({});
    await Order.deleteMany({});
    await Payment.deleteMany({});
  });

  describe('POST /api/orders/checkout', () => {
    beforeEach(async () => {
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product1._id, quantity: 2 },
          { productId: product2._id, quantity: 1 }
        ]
      });
      await cart.save();
    });

    it('should create order from cart and reserve stock', async () => {
      const response = await request(app)
        .post('/api/orders/checkout')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          shippingAddress: {
            street: '123 Test St',
            city: 'Test City',
            state: 'TS',
            country: 'Test Country',
            zipCode: '12345'
          }
        })
        .expect(201);

      expect(response.body).toHaveProperty('message', 'Order created successfully. Proceed to payment.');
      expect(response.body.order).toHaveProperty('_id');
      expect(response.body.order.status).toBe('PENDING_PAYMENT');
      expect(response.body.order.items).toHaveLength(2);
      expect(response.body.order.totalAmount).toBe(2 * 19.99 + 29.50);

      const updatedProduct1 = await Product.findById(product1._id);
      const updatedProduct2 = await Product.findById(product2._id);

      expect(updatedProduct1.availableStock).toBe(100 - 2);
      expect(updatedProduct1.reservedStock).toBe(2);
      expect(updatedProduct2.availableStock).toBe(50 - 1);
      expect(updatedProduct2.reservedStock).toBe(1);

      const cart = await Cart.findOne({ userId: regularUser._id });
      expect(cart.items).toHaveLength(0);
    });

    it('should not checkout with empty cart', async () => {
      await Cart.deleteMany({});

      const response = await request(app)
        .post('/api/orders/checkout')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error', 'Cart is empty');
    });

    it('should not checkout with insufficient stock', async () => {
   
      const cart = new Cart({
        userId: regularUser._id,
        items: [
          { productId: product3._id, quantity: 30 }
        ]
      });
      await cart.save();

      const response = await request(app)
        .post('/api/orders/checkout')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('Insufficient stock');
    });

    it('should not checkout without authentication', async () => {
      const response = await request(app)
        .post('/api/orders/checkout')
        .expect(401);

      expect(response.body).toHaveProperty('error');
    });

    it('should handle product becoming unavailable during checkout', async () => {
      await Product.findByIdAndUpdate(product1._id, { isActive: false });

      const response = await request(app)
        .post('/api/orders/checkout')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('not found or unavailable');
    });
  });

  describe('POST /api/orders/:id/pay', () => {
    let pendingOrder;

    beforeEach(async () => {
      pendingOrder = new Order({
        userId: regularUser._id,
        items: [
          {
            productId: product1._id,
            quantity: 2,
            priceAtPurchase: 19.99,
            productName: product1.name
          },
          {
            productId: product2._id,
            quantity: 1,
            priceAtPurchase: 29.50,
            productName: product2.name
          }
        ],
        totalAmount: 2 * 19.99 + 29.50,
        status: 'PENDING_PAYMENT'
      });
      await pendingOrder.save();

      await Product.findByIdAndUpdate(product1._id, {
        availableStock: 100 - 2,
        reservedStock: 2
      });
      await Product.findByIdAndUpdate(product2._id, {
        availableStock: 50 - 1,
        reservedStock: 1
      });
    });

    it('should process payment successfully and confirm order', async () => {
      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/pay`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          paymentMethod: 'credit_card'
        })
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Payment processed successfully');
      expect(response.body.order.status).toBe('PAID');
      expect(response.body.payment.status).toBe('SUCCESS');

      const updatedProduct1 = await Product.findById(product1._id);
      const updatedProduct2 = await Product.findById(product2._id);

      expect(updatedProduct1.availableStock).toBe(100 - 2);
      expect(updatedProduct1.reservedStock).toBe(0);
      expect(updatedProduct2.availableStock).toBe(50 - 1);
      expect(updatedProduct2.reservedStock).toBe(0);

      const payment = await Payment.findOne({ orderId: pendingOrder._id });
      expect(payment).toBeTruthy();
      expect(payment.status).toBe('SUCCESS');
    });

    it('should handle payment failure and release stock', async () => {

      
      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/pay`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          paymentMethod: 'credit_card'
        })
        .expect(400); 

      if (response.body.error === 'Payment failed') {
        const updatedProduct1 = await Product.findById(product1._id);
        const updatedProduct2 = await Product.findById(product2._id);

        expect(updatedProduct1.availableStock).toBe(100);
        expect(updatedProduct1.reservedStock).toBe(0);
        expect(updatedProduct2.availableStock).toBe(50);
        expect(updatedProduct2.reservedStock).toBe(0);

        const updatedOrder = await Order.findById(pendingOrder._id);
        expect(updatedOrder.status).toBe('CANCELLED');
      }
    });

    it('should not process payment for non-existent order', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();

      const response = await request(app)
        .post(`/api/orders/${nonExistentId}/pay`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Order not found');
    });

    it('should not process payment for another user\'s order', async () => {
      const otherUser = await User.create({
        name: 'Other User',
        email: 'otheruser@test.com',
        password: 'password123'
      });

      const otherUserLogin = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'otheruser@test.com',
          password: 'password123'
        });
      const otherUserToken = otherUserLogin.body.token;

      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/pay`)
        .set('Authorization', `Bearer ${otherUserToken}`)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied');
    });

    it('should not process payment for already paid order', async () => {
      await Order.findByIdAndUpdate(pendingOrder._id, { status: 'PAID' });

      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/pay`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('cannot be paid');
    });

    it('should not process payment for expired order', async () => {
     
      await Order.findByIdAndUpdate(pendingOrder._id, {
        expiresAt: new Date(Date.now() - 24 * 60 * 60 * 1000) 
      });

      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/pay`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error', 'Order has expired');
    });
  });

  describe('GET /api/orders', () => {
    beforeEach(async () => {
    
      await Order.create([
        {
          userId: regularUser._id,
          items: [{ productId: product1._id, quantity: 1, priceAtPurchase: 19.99, productName: product1.name }],
          totalAmount: 19.99,
          status: 'PAID'
        },
        {
          userId: regularUser._id,
          items: [{ productId: product2._id, quantity: 2, priceAtPurchase: 29.50, productName: product2.name }],
          totalAmount: 59.00,
          status: 'SHIPPED'
        },
        {
          userId: regularUser._id,
          items: [{ productId: product3._id, quantity: 1, priceAtPurchase: 7.99, productName: product3.name }],
          totalAmount: 7.99,
          status: 'DELIVERED'
        }
      ]);
    });

    it('should get user orders with pagination', async () => {
      const response = await request(app)
        .get('/api/orders')
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.orders).toHaveLength(3);
      expect(response.body.pagination).toHaveProperty('currentPage', 1);
      expect(response.body.pagination).toHaveProperty('totalPages', 1);
      expect(response.body.pagination).toHaveProperty('totalOrders', 3);
    });

    it('should filter orders by status', async () => {
      const response = await request(app)
        .get('/api/orders')
        .query({ status: 'PAID' })
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.orders).toHaveLength(1);
      expect(response.body.orders[0].status).toBe('PAID');
    });

    it('should not get orders without authentication', async () => {
      const response = await request(app)
        .get('/api/orders')
        .expect(401);

      expect(response.body).toHaveProperty('error');
    });

    it('should return empty array when no orders match filters', async () => {
      const response = await request(app)
        .get('/api/orders')
        .query({ status: 'CANCELLED' })
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.orders).toHaveLength(0);
    });
  });

  describe('GET /api/orders/:id', () => {
    let userOrder;

    beforeEach(async () => {
      userOrder = await Order.create({
        userId: regularUser._id,
        items: [
          {
            productId: product1._id,
            quantity: 1,
            priceAtPurchase: 19.99,
            productName: product1.name
          }
        ],
        totalAmount: 19.99,
        status: 'PAID'
      });
    });

    it('should get order details', async () => {
      const response = await request(app)
        .get(`/api/orders/${userOrder._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.order._id).toBe(userOrder._id.toString());
      expect(response.body.order.status).toBe('PAID');
      expect(response.body.order.items).toHaveLength(1);
    });

    it('should allow admin to view any order', async () => {
      const response = await request(app)
        .get(`/api/orders/${userOrder._id}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(200);

      expect(response.body.order._id).toBe(userOrder._id.toString());
    });

    it('should not allow user to view another user\'s order', async () => {
      const otherUser = await User.create({
        name: 'Other User',
        email: 'other@test.com',
        password: 'password123'
      });

      const otherUserLogin = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'other@test.com',
          password: 'password123'
        });
      const otherUserToken = otherUserLogin.body.token;

      const response = await request(app)
        .get(`/api/orders/${userOrder._id}`)
        .set('Authorization', `Bearer ${otherUserToken}`)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied');
    });

    it('should return 404 for non-existent order', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();

      const response = await request(app)
        .get(`/api/orders/${nonExistentId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Order not found');
    });
  });

  describe('POST /api/orders/:id/cancel', () => {
    let pendingOrder;
    let paidOrder;

    beforeEach(async () => {
      pendingOrder = await Order.create({
        userId: regularUser._id,
        items: [
          {
            productId: product1._id,
            quantity: 2,
            priceAtPurchase: 19.99,
            productName: product1.name
          }
        ],
        totalAmount: 39.98,
        status: 'PENDING_PAYMENT'
      });

      paidOrder = await Order.create({
        userId: regularUser._id,
        items: [
          {
            productId: product2._id,
            quantity: 1,
            priceAtPurchase: 29.50,
            productName: product2.name
          }
        ],
        totalAmount: 29.50,
        status: 'PAID'
      });

     
      await Product.findByIdAndUpdate(product1._id, {
        availableStock: 100 - 2,
        reservedStock: 2
      });
    });

    it('should cancel pending order and release stock', async () => {
      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/cancel`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Order cancelled successfully');
      expect(response.body.order.status).toBe('CANCELLED');


      const updatedProduct = await Product.findById(product1._id);
      expect(updatedProduct.availableStock).toBe(100);
      expect(updatedProduct.reservedStock).toBe(0);
    });

    it('should cancel paid order', async () => {
      const response = await request(app)
        .post(`/api/orders/${paidOrder._id}/cancel`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(200);

      expect(response.body.order.status).toBe('CANCELLED');
    });

    it('should not cancel shipped order', async () => {
      const shippedOrder = await Order.create({
        userId: regularUser._id,
        items: [
          {
            productId: product1._id,
            quantity: 1,
            priceAtPurchase: 19.99,
            productName: product1.name
          }
        ],
        totalAmount: 19.99,
        status: 'SHIPPED'
      });

      const response = await request(app)
        .post(`/api/orders/${shippedOrder._id}/cancel`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(400);

      expect(response.body).toHaveProperty('error');
      expect(response.body.error).toContain('cannot be cancelled');
    });

    it('should not cancel another user\'s order', async () => {
      const otherUser = await User.create({
        name: 'Other User',
        email: 'other@test.com',
        password: 'password123'
      });

      const otherUserLogin = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'other@test.com',
          password: 'password123'
        });
      const otherUserToken = otherUserLogin.body.token;

      const response = await request(app)
        .post(`/api/orders/${pendingOrder._id}/cancel`)
        .set('Authorization', `Bearer ${otherUserToken}`)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied');
    });
  });

  describe('Order expiry', () => {
    it('should automatically cancel expired orders', async () => {
      const expiredOrder = await Order.create({
        userId: regularUser._id,
        items: [
          {
            productId: product1._id,
            quantity: 1,
            priceAtPurchase: 19.99,
            productName: product1.name
          }
        ],
        totalAmount: 19.99,
        status: 'PENDING_PAYMENT',
        expiresAt: new Date(Date.now() - 60 * 1000) 
      });

      // Reserve stock
      await Product.findByIdAndUpdate(product1._id, {
        availableStock: 100 - 1,
        reservedStock: 1
      });

      const order = await Order.findById(expiredOrder._id);
      expect(order.isExpired).toBe(true);
    });
  });
});