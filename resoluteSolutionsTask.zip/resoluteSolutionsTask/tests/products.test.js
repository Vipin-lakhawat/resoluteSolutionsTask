const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../src/app');
const Product = require('../src/models/Product');
const User = require('../src/models/User');

describe('Products API', () => {
  let adminToken;
  let userToken;
  let adminUser;
  let regularUser;
  let testProduct;

  beforeAll(async () => {
    adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@test.com',
      password: 'password123',
      role: 'ADMIN'
    });

    regularUser = await User.create({
      name: 'Regular User',
      email: 'user@test.com',
      password: 'password123',
      role: 'USER'
    });

    const adminLogin = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'admin@test.com',
        password: 'password123'
      });
    adminToken = adminLogin.body.token;

    const userLogin = await request(app)
      .post('/api/auth/login')
      .send({
        email: 'user@test.com',
        password: 'password123'
      });
    userToken = userLogin.body.token;

    testProduct = await Product.create({
      name: 'Test Product',
      price: 29.99,
      description: 'A test product for testing purposes',
      availableStock: 100,
      category: 'Electronics'
    });
  });

  afterAll(async () => {
    await User.deleteMany({});
    await Product.deleteMany({});
  });

  describe('GET /api/products', () => {
    beforeEach(async () => {
      await Product.deleteMany({});
      
      await Product.create([
        {
          name: 'Product 1',
          price: 10.99,
          description: 'Description for product 1',
          availableStock: 50,
          category: 'Electronics'
        },
        {
          name: 'Product 2',
          price: 25.50,
          description: 'Description for product 2',
          availableStock: 30,
          category: 'Books'
        },
        {
          name: 'Another Product',
          price: 5.99,
          description: 'Description for another product',
          availableStock: 100,
          category: 'Electronics'
        }
      ]);
    });

    it('should get all products with pagination', async () => {
      const response = await request(app)
        .get('/api/products')
        .expect(200);

      expect(response.body.products).toHaveLength(3);
      expect(response.body.pagination).toHaveProperty('currentPage', 1);
      expect(response.body.pagination).toHaveProperty('totalPages', 1);
      expect(response.body.pagination).toHaveProperty('totalProducts', 3);
    });

    it('should filter products by category', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ category: 'Electronics' })
        .expect(200);

      expect(response.body.products).toHaveLength(2);
      expect(response.body.products[0].category).toBe('Electronics');
    });

    it('should search products by name', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ search: 'Another' })
        .expect(200);

      expect(response.body.products).toHaveLength(1);
      expect(response.body.products[0].name).toContain('Another');
    });

    it('should filter products by price range', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ minPrice: 10, maxPrice: 20 })
        .expect(200);

      expect(response.body.products).toHaveLength(1);
      expect(response.body.products[0].price).toBe(10.99);
    });

    it('should sort products by price', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ sort: 'price', order: 'asc' })
        .expect(200);

      expect(response.body.products[0].price).toBe(5.99);
      expect(response.body.products[2].price).toBe(25.50);
    });

    it('should return empty array when no products match filters', async () => {
      const response = await request(app)
        .get('/api/products')
        .query({ category: 'NonExistent' })
        .expect(200);

      expect(response.body.products).toHaveLength(0);
    });
  });

  describe('GET /api/products/:id', () => {
    it('should get a single product by ID', async () => {
      const response = await request(app)
        .get(`/api/products/${testProduct._id}`)
        .expect(200);

      expect(response.body.product._id).toBe(testProduct._id.toString());
      expect(response.body.product.name).toBe('Test Product');
      expect(response.body.product.price).toBe(29.99);
    });

    it('should return 404 for non-existent product', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();
      const response = await request(app)
        .get(`/api/products/${nonExistentId}`)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Product not found');
    });

    it('should return 404 for invalid product ID format', async () => {
      const response = await request(app)
        .get('/api/products/invalid-id')
        .expect(500);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('POST /api/products', () => {
    it('should create a new product as admin', async () => {
      const newProduct = {
        name: 'New Test Product',
        price: 39.99,
        description: 'A new test product description',
        availableStock: 50,
        category: 'Home'
      };

      const response = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(newProduct)
        .expect(201);

      expect(response.body).toHaveProperty('message', 'Product created successfully');
      expect(response.body.product.name).toBe(newProduct.name);
      expect(response.body.product.price).toBe(newProduct.price);
      expect(response.body.product.availableStock).toBe(newProduct.availableStock);
    });

    it('should not create product without authentication', async () => {
      const newProduct = {
        name: 'New Product',
        price: 19.99,
        description: 'Description',
        availableStock: 10
      };

      const response = await request(app)
        .post('/api/products')
        .send(newProduct)
        .expect(401);

      expect(response.body).toHaveProperty('error');
    });

    it('should not create product without admin role', async () => {
      const newProduct = {
        name: 'New Product',
        price: 19.99,
        description: 'Description',
        availableStock: 10
      };

      const response = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${userToken}`)
        .send(newProduct)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied. Admin privileges required.');
    });

    it('should validate product data', async () => {
      const invalidProduct = {
        name: '', 
        price: -10, 
        description: 'Short', 
        availableStock: -5 
      };

      const response = await request(app)
        .post('/api/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send(invalidProduct)
        .expect(400);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('PUT /api/products/:id', () => {
    it('should update product as admin', async () => {
      const updates = {
        name: 'Updated Product Name',
        price: 49.99,
        description: 'Updated description'
      };

      const response = await request(app)
        .put(`/api/products/${testProduct._id}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send(updates)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Product updated successfully');
      expect(response.body.product.name).toBe(updates.name);
      expect(response.body.product.price).toBe(updates.price);
    });

    it('should not update product without admin role', async () => {
      const updates = { name: 'Updated Name' };

      const response = await request(app)
        .put(`/api/products/${testProduct._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send(updates)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied. Admin privileges required.');
    });

    it('should return 404 when updating non-existent product', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();
      const updates = { name: 'Updated Name' };

      const response = await request(app)
        .put(`/api/products/${nonExistentId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send(updates)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Product not found');
    });

    it('should validate update data', async () => {
      const invalidUpdates = {
        price: -100,
        availableStock: -10
      };

      const response = await request(app)
        .put(`/api/products/${testProduct._id}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send(invalidUpdates)
        .expect(400);

      expect(response.body).toHaveProperty('error');
    });
  });

  describe('DELETE /api/products/:id', () => {
    let productToDelete;

    beforeEach(async () => {
      productToDelete = await Product.create({
        name: 'Product to Delete',
        price: 19.99,
        description: 'This product will be deleted',
        availableStock: 25
      });
    });

    it('should soft delete product as admin', async () => {
      const response = await request(app)
        .delete(`/api/products/${productToDelete._id}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(200);

      expect(response.body).toHaveProperty('message', 'Product deleted successfully');

     
      const deletedProduct = await Product.findById(productToDelete._id);
      expect(deletedProduct.isActive).toBe(false);
    });

    it('should not delete product without admin role', async () => {
      const response = await request(app)
        .delete(`/api/products/${productToDelete._id}`)
        .set('Authorization', `Bearer ${userToken}`)
        .expect(403);

      expect(response.body).toHaveProperty('error', 'Access denied. Admin privileges required.');
    });

    it('should return 404 when deleting non-existent product', async () => {
      const nonExistentId = new mongoose.Types.ObjectId();

      const response = await request(app)
        .delete(`/api/products/${nonExistentId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .expect(404);

      expect(response.body).toHaveProperty('error', 'Product not found');
    });

    it('should not return soft-deleted products in listings', async () => {
    
      await Product.findByIdAndUpdate(productToDelete._id, { isActive: false });

      const response = await request(app)
        .get('/api/products')
        .expect(200);

      const deletedProductInList = response.body.products.find(
        p => p._id === productToDelete._id.toString()
      );
      expect(deletedProductInList).toBeUndefined();
    });
  });
});