const Product = require('../models/Product');
const logger = require('../utils/logger');

class InventoryService {
  async reserveStock(items, session = null) {
    const operations = [];
    
    for (const item of items) {
      const product = await Product.findById(item.productId).session(session);
      if (!product) {
        throw new Error(`Product not found: ${item.productId}`);
      }

      if (product.availableStock < item.quantity) {
        throw new Error(`Insufficient stock for ${product.name}. Available: ${product.availableStock}, Requested: ${item.quantity}`);
      }

      operations.push({
        productId: product._id,
        productName: product.name,
        quantity: item.quantity,
        currentStock: product.availableStock
      });
    }

    for (const operation of operations) {
      const product = await Product.findById(operation.productId).session(session);
      await product.reserveStock(operation.quantity);
      
      logger.info('Stock reserved successfully', {
        productId: operation.productId,
        productName: operation.productName,
        quantity: operation.quantity,
        previousStock: operation.currentStock,
        newAvailableStock: product.availableStock,
        reservedStock: product.reservedStock
      });
    }

    return operations;
  }

  async releaseStock(items, session = null) {
    for (const item of items) {
      const product = await Product.findById(item.productId).session(session);
      if (!product) {
        logger.warn('Product not found during stock release', {
          productId: item.productId
        });
        continue;
      }

      const previousAvailable = product.availableStock;
      const previousReserved = product.reservedStock;

      await product.releaseStock(item.quantity);

      logger.info('Stock released successfully', {
        productId: product._id,
        productName: product.name,
        quantity: item.quantity,
        previousAvailable,
        previousReserved,
        newAvailableStock: product.availableStock,
        newReservedStock: product.reservedStock
      });
    }
  }

  async confirmStockReduction(items, session = null) {
    for (const item of items) {
      const product = await Product.findById(item.productId).session(session);
      if (!product) {
        throw new Error(`Product not found: ${item.productId}`);
      }

      const previousReserved = product.reservedStock;

      await product.confirmStockReduction(item.quantity);

      logger.info('Stock reduction confirmed', {
        productId: product._id,
        productName: product.name,
        quantity: item.quantity,
        previousReserved,
        newReservedStock: product.reservedStock
      });
    }
  }

  async getLowStockProducts(threshold = 10) {
    return await Product.getLowStockProducts(threshold);
  }

  async updateStock(productId, newStock) {
    const product = await Product.findById(productId);
    if (!product) {
      throw new Error('Product not found');
    }

    const stockDifference = newStock - product.totalStock;
    product.availableStock = newStock;
    product.reservedStock = 0;

    await product.save();

    logger.info('Stock updated manually', {
      productId: product._id,
      productName: product.name,
      previousTotalStock: product.totalStock - stockDifference,
      newTotalStock: newStock,
      difference: stockDifference
    });

    return product;
  }
}

module.exports = new InventoryService();