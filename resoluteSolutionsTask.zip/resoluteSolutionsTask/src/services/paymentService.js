const logger = require('../utils/logger');

class PaymentService {
  async processPayment(order, paymentDetails = {}) {
    try {
      logger.info('Processing payment for order', {
        orderId: order._id,
        amount: order.totalAmount,
        ...paymentDetails
      });

      await new Promise(resolve => setTimeout(resolve, 2000));
  
      const transactionId = `txn_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const isSuccess = Math.random() > 0.1;

      if (isSuccess) {
        logger.info('Payment processed successfully', {
          orderId: order._id,
          transactionId,
          amount: order.totalAmount
        });

        return {
          success: true,
          transactionId,
          status: 'SUCCESS',
          gatewayResponse: {
            id: transactionId,
            status: 'succeeded',
            amount: order.totalAmount
          }
        };
      } else {
        logger.warn('Payment processing failed', {
          orderId: order._id,
          transactionId,
          amount: order.totalAmount
        });

        return {
          success: false,
          transactionId,
          status: 'FAILED',
          gatewayResponse: {
            id: transactionId,
            status: 'failed',
            error: 'Insufficient funds'
          }
        };
      }
    } catch (error) {
      logger.error('Payment processing error', {
        error: error.message,
        orderId: order._id
      });
      throw error;
    }
  }

  async refundPayment(payment, amount = null) {
    try {
      const refundAmount = amount || payment.amount;
      
      logger.info('Processing refund', {
        paymentId: payment._id,
        transactionId: payment.transactionId,
        refundAmount
      });
      await new Promise(resolve => setTimeout(resolve, 1500));

      logger.info('Refund processed successfully', {
        paymentId: payment._id,
        refundAmount
      });

      return {
        success: true,
        refundId: `ref_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        amount: refundAmount
      };
    } catch (error) {
      logger.error('Refund processing error', {
        error: error.message,
        paymentId: payment._id
      });
      throw error;
    }
  }
}

module.exports = new PaymentService();