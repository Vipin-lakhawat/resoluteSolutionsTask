const logger = require('../utils/logger');

class EmailService {
  async sendOrderConfirmation(order, user) {
    try {
      logger.info('Sending order confirmation email', {
        to: user.email,
        orderId: order._id,
        subject: `Order Confirmation - #${order._id}`
      });

      await new Promise(resolve => setTimeout(resolve, 1000));

      logger.info('Order confirmation email sent successfully', {
        to: user.email,
        orderId: order._id
      });

      return { success: true, message: 'Email sent successfully' };
    } catch (error) {
      logger.error('Failed to send order confirmation email', {
        error: error.message,
        orderId: order._id,
        user: user.email
      });
      throw error;
    }
  }

  async sendShippingNotification(order, user) {
    try {
      logger.info('Sending shipping notification email', {
        to: user.email,
        orderId: order._id,
        subject: `Your Order Has Shipped - #${order._id}`
      });

      await new Promise(resolve => setTimeout(resolve, 1000));

      logger.info('Shipping notification email sent successfully');
      return { success: true, message: 'Shipping notification sent' };
    } catch (error) {
      logger.error('Failed to send shipping notification email', error);
      throw error;
    }
  }

  async sendDeliveryNotification(order, user) {
    try {
      logger.info('Sending delivery notification email', {
        to: user.email,
        orderId: order._id,
        subject: `Your Order Has Been Delivered - #${order._id}`
      });

      await new Promise(resolve => setTimeout(resolve, 1000));

      logger.info('Delivery notification email sent successfully');
      return { success: true, message: 'Delivery notification sent' };
    } catch (error) {
      logger.error('Failed to send delivery notification email', error);
      throw error;
    }
  }
}

module.exports = new EmailService();