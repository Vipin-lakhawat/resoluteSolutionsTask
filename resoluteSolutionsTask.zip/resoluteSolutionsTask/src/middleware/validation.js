const Joi = require('joi');
const { objectId } = require('../utils/helpers');

const registerValidation = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(50).required().trim(),
    email: Joi.string().email().required().trim().lowercase(),
    password: Joi.string().min(6).required(),
    role: Joi.string().valid('USER', 'ADMIN').default('USER')
  });

  return schema.validate(data);
};

const loginValidation = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required().trim().lowercase(),
    password: Joi.string().required()
  });

  return schema.validate(data);
};

const productValidation = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(100).required().trim(),
    price: Joi.number().min(0).precision(2).required(),
    description: Joi.string().min(10).max(1000).required().trim(),
    availableStock: Joi.number().min(0).integer().required(),
    category: Joi.string().max(50).trim().default('General'),
    images: Joi.array().items(Joi.string().uri()).default([])
  });

  return schema.validate(data);
};

const productUpdateValidation = (data) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(100).trim(),
    price: Joi.number().min(0).precision(2),
    description: Joi.string().min(10).max(1000).trim(),
    availableStock: Joi.number().min(0).integer(),
    category: Joi.string().max(50).trim(),
    images: Joi.array().items(Joi.string().uri()),
    isActive: Joi.boolean()
  });

  return schema.validate(data);
};

const cartItemValidation = (data) => {
  const schema = Joi.object({
    productId: Joi.string().custom(objectId, 'ObjectId validation').required(),
    quantity: Joi.number().min(1).max(100).integer().required()
  });

  return schema.validate(data);
};

const orderStatusValidation = (data) => {
  const schema = Joi.object({
    status: Joi.string().valid('SHIPPED', 'DELIVERED', 'CANCELLED').required()
  });

  return schema.validate(data);
};

const shippingAddressValidation = (data) => {
  const schema = Joi.object({
    street: Joi.string().required().trim(),
    city: Joi.string().required().trim(),
    state: Joi.string().required().trim(),
    country: Joi.string().required().trim(),
    zipCode: Joi.string().required().trim()
  });

  return schema.validate(data);
};

const queryValidation = (data) => {
  const schema = Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(10),
    sort: Joi.string().trim(),
    order: Joi.string().valid('asc', 'desc').default('asc'),
    search: Joi.string().trim(),
    category: Joi.string().trim(),
    minPrice: Joi.number().min(0),
    maxPrice: Joi.number().min(0),
    status: Joi.string().trim()
  });

  return schema.validate(data);
};

module.exports = {
  registerValidation,
  loginValidation,
  productValidation,
  productUpdateValidation,
  cartItemValidation,
  orderStatusValidation,
  shippingAddressValidation,
  queryValidation
};