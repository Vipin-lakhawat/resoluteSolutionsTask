const express = require('express');
const { auth, adminAuth } = require('../middleware/auth');
const {
  getAllOrders,
  updateOrderStatus,
  getDashboardStats,
  getLowStockProducts
} = require('../controllers/adminController');
const router = express.Router();

router.use(auth, adminAuth);
router.get('/orders', getAllOrders);
router.patch('/orders/:id/status', updateOrderStatus);
router.get('/dashboard/stats', getDashboardStats);
router.get('/products/low-stock', getLowStockProducts);

module.exports = router;