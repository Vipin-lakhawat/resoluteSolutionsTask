const express = require('express');
const { auth, adminAuth } = require('../middleware/auth');
const {
  createProduct,
  updateProduct,
  deleteProduct,
  getProducts,
  getProductById
} = require('../controllers/productController');
const router = express.Router();
router.get('/', getProducts);
router.get('/:id', getProductById);
router.post('/', auth, adminAuth, createProduct);
router.put('/:id', auth, adminAuth, updateProduct);
router.delete('/:id', auth, adminAuth, deleteProduct);

module.exports = router;