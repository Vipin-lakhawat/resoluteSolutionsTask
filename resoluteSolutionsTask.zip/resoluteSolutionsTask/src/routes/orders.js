const express = require('express');
const { auth } = require('../middleware/auth');
const {
  checkout,
  processPayment,
  getUserOrders,
  getOrderDetails,
  cancelOrder
} = require('../controllers/orderController');
const router = express.Router();

router.use(auth);

router.get('/', getUserOrders);

router.get('/:id', getOrderDetails);

router.post('/checkout', checkout);

router.post('/:id/pay', processPayment);

router.post('/:id/cancel', cancelOrder);

module.exports = router;