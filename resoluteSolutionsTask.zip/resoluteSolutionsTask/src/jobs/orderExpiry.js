const cron = require('node-cron');
const mongoose = require('mongoose');
const Order = require('../models/Order');
const Product = require('../models/Product');
const { ORDER_STATUS } = require('../../config/constants');
const inventoryService = require('../services/inventoryService');
const logger = require('../utils/logger');

const orderExpiryJob = cron.schedule('* * * * *', async () => {
  try {
    const expiredOrders = await Order.find({
      status: ORDER_STATUS.PENDING_PAYMENT,
      expiresAt: { $lte: new Date() }
    }).populate('items.productId');

    logger.info(`Found ${expiredOrders.length} expired orders to process`);

    for (const order of expiredOrders) {
      const session = await mongoose.startSession();
      
      try {
        session.startTransaction();

        await inventoryService.releaseStock(order.items, session);

        order.status = ORDER_STATUS.CANCELLED;
        await order.save({ session });

        await session.commitTransaction();
        
        logger.info('Successfully cancelled expired order and released stock', {
          orderId: order._id,
          itemsCount: order.items.length
        });

      } catch (error) {
        await session.abortTransaction();
        logger.error('Error cancelling expired order', {
          orderId: order._id,
          error: error.message
        });
      } finally {
        session.endSession();
      }
    }

    if (expiredOrders.length > 0) {
      logger.info('Order expiry processing completed', {
        processedOrders: expiredOrders.length
      });
    }
  } catch (error) {
    logger.error('Error in order expiry job:', error);
  }
});

process.on('SIGTERM', () => {
  orderExpiryJob.stop();
  logger.info('Order expiry job stopped');
});

module.exports = orderExpiryJob;