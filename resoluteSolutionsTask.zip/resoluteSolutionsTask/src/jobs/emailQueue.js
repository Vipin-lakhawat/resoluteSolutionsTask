const Queue = require('bull');
const Order = require('../models/Order');
const User = require('../models/User');
const emailService = require('../services/emailService');
const { createRedisClient } = require('../../config/redis');
const logger = require('../utils/logger');

const emailQueue = new Queue('email', {
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
  },
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 1000
    },
    removeOnComplete: true,
    removeOnFail: false
  }
});

emailQueue.process('sendOrderConfirmation', async (job) => {
  const { orderId, userEmail, userName } = job.data;
  
  try {
    const order = await Order.findById(orderId).populate('userId');
    const user = await User.findById(order.userId);
    
    if (!order || !user) {
      throw new Error('Order or user not found');
    }

    const result = await emailService.sendOrderConfirmation(order, user);
    
    logger.info('Order confirmation email processed successfully', {
      jobId: job.id,
      orderId,
      userEmail
    });
    
    return result;
  } catch (error) {
    logger.error('Failed to process order confirmation email', {
      jobId: job.id,
      orderId,
      error: error.message
    });
    throw error;
  }
});

emailQueue.process('sendShippingNotification', async (job) => {
  const { orderId } = job.data;
  
  try {
    const order = await Order.findById(orderId).populate('userId');
    const user = await User.findById(order.userId);
    
    if (!order || !user) {
      throw new Error('Order or user not found');
    }

    const result = await emailService.sendShippingNotification(order, user);
    
    logger.info('Shipping notification email processed successfully', {
      jobId: job.id,
      orderId
    });
    
    return result;
  } catch (error) {
    logger.error('Failed to process shipping notification email', {
      jobId: job.id,
      orderId,
      error: error.message
    });
    throw error;
  }
});

emailQueue.process('sendDeliveryNotification', async (job) => {
  const { orderId } = job.data;
  
  try {
    const order = await Order.findById(orderId).populate('userId');
    const user = await User.findById(order.userId);
    
    if (!order || !user) {
      throw new Error('Order or user not found');
    }

    const result = await emailService.sendDeliveryNotification(order, user);
    
    logger.info('Delivery notification email processed successfully', {
      jobId: job.id,
      orderId
    });
    
    return result;
  } catch (error) {
    logger.error('Failed to process delivery notification email', {
      jobId: job.id,
      orderId,
      error: error.message
    });
    throw error;
  }
});

emailQueue.on('completed', (job, result) => {
  logger.info('Email job completed', {
    jobId: job.id,
    queue: job.queue.name,
    result
  });
});

emailQueue.on('failed', (job, err) => {
  logger.error('Email job failed', {
    jobId: job.id,
    queue: job.queue.name,
    error: err.message,
    attemptsMade: job.attemptsMade
  });
});

emailQueue.on('stalled', (job) => {
  logger.warn('Email job stalled', {
    jobId: job.id,
    queue: job.queue.name
  });
});

module.exports = emailQueue;