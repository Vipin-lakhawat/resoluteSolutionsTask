const cron = require('node-cron');
const Product = require('../models/Product');
const logger = require('../utils/logger');

const stockReplenishmentJob = cron.schedule('0 2 * * *', async () => {
  try {
    const lowStockThreshold = 5; 
    const lowStockProducts = await Product.getLowStockProducts(lowStockThreshold);

    if (lowStockProducts.length > 0) {
      logger.warn('Low stock products detected', {
        count: lowStockProducts.length,
        threshold: lowStockThreshold,
        products: lowStockProducts.map(p => ({
          id: p._id,
          name: p.name,
          availableStock: p.availableStock,
          reservedStock: p.reservedStock
        }))
      });

      
      logger.info('Low stock alert processed', {
        alertCount: lowStockProducts.length
      });
    } else {
      logger.info('No low stock products found', {
        threshold: lowStockThreshold
      });
    }
  } catch (error) {
    logger.error('Error in stock replenishment job:', error);
  }
});


process.on('SIGTERM', () => {
  stockReplenishmentJob.stop();
  logger.info('Stock replenishment job stopped');
});

module.exports = stockReplenishmentJob;