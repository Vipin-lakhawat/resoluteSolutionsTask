const mongoose = require('mongoose');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const Product = require('../models/Product');
const Payment = require('../models/Payment');
const { ORDER_STATUS } = require('../../config/constants');
const inventoryService = require('../services/inventoryService');
const paymentService = require('../services/paymentService');
const emailQueue = require('../jobs/emailQueue');
const { queryValidation } = require('../middleware/validation');
const { buildQuery, buildSort } = require('../utils/helpers');
const logger = require('../utils/logger');

exports.checkout = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const cart = await Cart.findByUserId(req.user._id);
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ error: 'Cart is empty' });
    }

    let totalAmount = 0;
    const orderItems = [];

    for (const item of cart.items) {
      const product = await Product.findById(item.productId._id).session(session);
      if (!product || !product.isActive) {
        throw new Error(`Product ${item.productId.name} not found or unavailable`);
      }

      if (product.availableStock < item.quantity) {
        throw new Error(`Insufficient stock for ${product.name}. Available: ${product.availableStock}, Requested: ${item.quantity}`);
      }

      const itemTotal = product.price * item.quantity;
      totalAmount += itemTotal;

      orderItems.push({
        productId: product._id,
        quantity: item.quantity,
        priceAtPurchase: product.price,
        productName: product.name,
        productImage: product.images[0] || null
      });
    }

    await inventoryService.reserveStock(
      cart.items.map(item => ({
        productId: item.productId._id,
        quantity: item.quantity
      })),
      session
    );

    const order = new Order({
      userId: req.user._id,
      items: orderItems,
      totalAmount,
      status: ORDER_STATUS.PENDING_PAYMENT,
      shippingAddress: req.body.shippingAddress || {}
    });

    await order.save({ session });

    await cart.clear();

    await session.commitTransaction();
    session.endSession();

    logger.info('Order created successfully', {
      orderId: order._id,
      userId: req.user._id,
      totalAmount,
      itemsCount: order.items.length
    });

    res.status(201).json({
      message: 'Order created successfully. Proceed to payment.',
      order: order.toObject()
    });

  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    
    logger.error('Checkout error', {
      userId: req.user._id,
      error: error.message
    });
    
    res.status(400).json({ error: error.message });
  }
};

exports.processPayment = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Access denied' });
    }

    if (order.status !== ORDER_STATUS.PENDING_PAYMENT) {
      return res.status(400).json({ 
        error: `Order cannot be paid. Current status: ${order.status}` 
      });
    }

    if (order.isExpired) {
      return res.status(400).json({ error: 'Order has expired. Please create a new order.' });
    }

    const paymentResult = await paymentService.processPayment(order, req.body.paymentDetails);

    const payment = new Payment({
      orderId: order._id,
      transactionId: paymentResult.transactionId,
      amount: order.totalAmount,
      status: paymentResult.status,
      paymentMethod: req.body.paymentMethod || 'credit_card',
      gatewayResponse: paymentResult.gatewayResponse
    });

    await payment.save({ session });

    if (paymentResult.success) {
      await inventoryService.confirmStockReduction(order.items, session);

      order.status = ORDER_STATUS.PAID;
      order.paymentId = payment._id;
      await order.save({ session });

      await session.commitTransaction();
      session.endSession();


      await emailQueue.add('sendOrderConfirmation', {
        orderId: order._id,
        userEmail: req.user.email,
        userName: req.user.name
      });

      logger.info('Payment processed successfully', {
        orderId: order._id,
        paymentId: payment._id,
        transactionId: payment.transactionId,
        amount: order.totalAmount
      });

      res.json({
        message: 'Payment processed successfully',
        order: order.toObject(),
        payment: payment.toObject()
      });
    } else {
  
      await inventoryService.releaseStock(order.items, session);

      order.status = ORDER_STATUS.CANCELLED;
      await order.save({ session });

      await session.commitTransaction();
      session.endSession();

      logger.warn('Payment failed', {
        orderId: order._id,
        transactionId: payment.transactionId,
        reason: paymentResult.gatewayResponse?.error
      });

      res.status(400).json({
        error: 'Payment failed',
        details: paymentResult.gatewayResponse
      });
    }

  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    
    logger.error('Payment processing error', {
      orderId: req.params.id,
      userId: req.user._id,
      error: error.message
    });
    
    res.status(400).json({ error: error.message });
  }
};

exports.getUserOrders = async (req, res) => {
  try {
    const { error } = queryValidation(req.query);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { page = 1, limit = 10, status } = req.query;

    const query = { userId: req.user._id };
    if (status) query.status = status;

    const orders = await Order.find(query)
      .sort({ createdAt: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .populate('paymentId', 'transactionId amount status createdAt')
      .select('-__v');

    const total = await Order.countDocuments(query);

    logger.info('User orders fetched', {
      userId: req.user._id,
      count: orders.length,
      page,
      status
    });

    res.json({
      orders,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalOrders: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    logger.error('Error fetching user orders', {
      userId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching orders' });
  }
};

exports.getOrderDetails = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('paymentId', 'transactionId amount status paymentMethod createdAt')
      .select('-__v');

    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (order.userId.toString() !== req.user._id.toString() && req.user.role !== 'ADMIN') {
      return res.status(403).json({ error: 'Access denied' });
    }

    const populatedItems = await Promise.all(order.items.map(async (item) => {
      const product = await Product.findById(item.productId).select('name images');
      return {
        ...item.toObject(),
        product: {
          _id: product._id,
          name: product.name,
          images: product.images
        }
      };
    }));

    const orderWithDetails = {
      ...order.toObject(),
      items: populatedItems
    };

    res.json({ order: orderWithDetails });
  } catch (error) {
    logger.error('Error fetching order details', {
      orderId: req.params.id,
      userId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching order details' });
  }
};

exports.cancelOrder = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    if (order.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ error: 'Access denied' });
    }

    if (!order.canBeCancelled()) {
      return res.status(400).json({ 
        error: `Order cannot be cancelled in its current status: ${order.status}` 
      });
    }

    if (order.status === ORDER_STATUS.PENDING_PAYMENT) {
      await inventoryService.releaseStock(order.items, session);
    }

    order.status = ORDER_STATUS.CANCELLED;
    await order.save({ session });

    await session.commitTransaction();
    session.endSession();

    logger.info('Order cancelled successfully', {
      orderId: order._id,
      userId: req.user._id,
      previousStatus: order.status
    });

    res.json({
      message: 'Order cancelled successfully',
      order: order.toObject()
    });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    
    logger.error('Error cancelling order', {
      orderId: req.params.id,
      userId: req.user._id,
      error: error.message
    });
    
    res.status(400).json({ error: error.message });
  }
};