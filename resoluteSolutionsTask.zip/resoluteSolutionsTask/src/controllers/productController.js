const Product = require('../models/Product');
const { productValidation, productUpdateValidation, queryValidation } = require('../middleware/validation');
const { buildQuery, buildSort } = require('../utils/helpers');
const logger = require('../utils/logger');

exports.getProducts = async (req, res) => {
  try {
    const { error } = queryValidation(req.query);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const {
      page = 1,
      limit = 10,
      sort = 'name',
      order = 'asc',
      search,
      category,
      minPrice,
      maxPrice
    } = req.query;

    const query = buildQuery({ search, category, minPrice, maxPrice });
    query.isActive = true;

    const sortOptions = buildSort(sort, order);

    const products = await Product.find(query)
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .select('-__v');

    const total = await Product.countDocuments(query);

    logger.info('Products fetched successfully', {
      count: products.length,
      page,
      limit,
      total
    });

    res.json({
      products,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalProducts: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    logger.error('Error fetching products', { error: error.message });
    res.status(500).json({ error: 'Server error fetching products' });
  }
};

exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findOne({ 
      _id: req.params.id, 
      isActive: true 
    }).select('-__v');

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ product });
  } catch (error) {
    logger.error('Error fetching product', {
      productId: req.params.id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching product' });
  }
};

exports.createProduct = async (req, res) => {
  try {
    const { error } = productValidation(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const product = new Product(req.body);
    await product.save();

    logger.info('Product created successfully', {
      productId: product._id,
      name: product.name,
      createdBy: req.user._id
    });

    res.status(201).json({
      message: 'Product created successfully',
      product: product.toObject()
    });
  } catch (error) {
    logger.error('Error creating product', {
      error: error.message,
      createdBy: req.user._id
    });
    res.status(500).json({ error: 'Server error creating product' });
  }
};

exports.updateProduct = async (req, res) => {
  try {
    const { error } = productUpdateValidation(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    Object.keys(req.body).forEach(key => {
      product[key] = req.body[key];
    });

    await product.save();

    logger.info('Product updated successfully', {
      productId: product._id,
      name: product.name,
      updatedBy: req.user._id
    });

    res.json({
      message: 'Product updated successfully',
      product: product.toObject()
    });
  } catch (error) {
    logger.error('Error updating product', {
      productId: req.params.id,
      error: error.message,
      updatedBy: req.user._id
    });
    res.status(500).json({ error: 'Server error updating product' });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    product.isActive = false;
    await product.save();

    logger.info('Product deleted successfully', {
      productId: product._id,
      name: product.name,
      deletedBy: req.user._id
    });

    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    logger.error('Error deleting product', {
      productId: req.params.id,
      error: error.message,
      deletedBy: req.user._id
    });
    res.status(500).json({ error: 'Server error deleting product' });
  }
};