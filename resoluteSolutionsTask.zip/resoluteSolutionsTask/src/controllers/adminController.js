const Order = require('../models/Order');
const Product = require('../models/Product');
const User = require('../models/User');
const Payment = require('../models/Payment');
const { ORDER_STATUS } = require('../../config/constants');
const { orderStatusValidation, queryValidation } = require('../middleware/validation');
const { buildQuery, buildSort } = require('../utils/helpers');
const emailQueue = require('../jobs/emailQueue');
const logger = require('../utils/logger');

exports.getAllOrders = async (req, res) => {
  try {
    const { error } = queryValidation(req.query);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const {
      page = 1,
      limit = 10,
      sort = 'createdAt',
      order = 'desc',
      status,
      search
    } = req.query;

    const query = buildQuery({ status, search });
    
    const sortOptions = buildSort(sort, order);

    const orders = await Order.find(query)
      .populate('userId', 'name email')
      .populate('paymentId', 'transactionId amount status')
      .sort(sortOptions)
      .limit(limit * 1)
      .skip((page - 1) * limit)
      .select('-__v');

    const total = await Order.countDocuments(query);

    logger.info('Admin fetched all orders', {
      adminId: req.user._id,
      count: orders.length,
      page,
      filters: { status, search }
    });

    res.json({
      orders,
      pagination: {
        currentPage: Number(page),
        totalPages: Math.ceil(total / limit),
        totalOrders: total,
        hasNext: page < Math.ceil(total / limit),
        hasPrev: page > 1
      }
    });
  } catch (error) {
    logger.error('Error fetching all orders', {
      adminId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching orders' });
  }
};

exports.updateOrderStatus = async (req, res) => {
  try {
    const { error } = orderStatusValidation(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const order = await Order.findById(req.params.id).populate('userId');
    if (!order) {
      return res.status(404).json({ error: 'Order not found' });
    }

    const newStatus = req.body.status;

    await order.updateStatus(newStatus);

    if (newStatus === ORDER_STATUS.SHIPPED) {
      await emailQueue.add('sendShippingNotification', {
        orderId: order._id,
        userEmail: order.userId.email,
        userName: order.userId.name
      });
    } else if (newStatus === ORDER_STATUS.DELIVERED) {
      await emailQueue.add('sendDeliveryNotification', {
        orderId: order._id,
        userEmail: order.userId.email,
        userName: order.userId.name
      });
    }

    logger.info('Order status updated by admin', {
      adminId: req.user._id,
      orderId: order._id,
      oldStatus: order.status,
      newStatus,
      userId: order.userId._id
    });

    res.json({
      message: 'Order status updated successfully',
      order: order.toObject()
    });
  } catch (error) {
    logger.error('Error updating order status', {
      adminId: req.user._id,
      orderId: req.params.id,
      error: error.message
    });
    res.status(400).json({ error: error.message });
  }
};

exports.getDashboardStats = async (req, res) => {
  try {
    const today = new Date();
    const startOfToday = new Date(today.setHours(0, 0, 0, 0));
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);

    const totalUsers = await User.countDocuments();
    const totalProducts = await Product.countDocuments({ isActive: true });
    const totalOrders = await Order.countDocuments();

    const revenueStats = await Payment.aggregate([
      {
        $match: {
          status: 'SUCCESS',
          createdAt: { $gte: startOfMonth }
        }
      },
      {
        $group: {
          _id: null,
          monthlyRevenue: { $sum: '$amount' },
          totalTransactions: { $sum: 1 }
        }
      }
    ]);

    const todayRevenue = await Payment.aggregate([
      {
        $match: {
          status: 'SUCCESS',
          createdAt: { $gte: startOfToday }
        }
      },
      {
        $group: {
          _id: null,
          amount: { $sum: '$amount' }
        }
      }
    ]);

    const orderStatusStats = await Order.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    const stats = {
      totalUsers,
      totalProducts,
      totalOrders,
      monthlyRevenue: revenueStats[0]?.monthlyRevenue || 0,
      todayRevenue: todayRevenue[0]?.amount || 0,
      totalTransactions: revenueStats[0]?.totalTransactions || 0,
      orderStatus: orderStatusStats.reduce((acc, stat) => {
        acc[stat._id] = stat.count;
        return acc;
      }, {})
    };

    logger.info('Dashboard stats fetched', {
      adminId: req.user._id
    });

    res.json({ stats });
  } catch (error) {
    logger.error('Error fetching dashboard stats', {
      adminId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching dashboard stats' });
  }
};

exports.getLowStockProducts = async (req, res) => {
  try {
    const threshold = parseInt(req.query.threshold) || 10;
    
    const lowStockProducts = await Product.getLowStockProducts(threshold);

    logger.info('Low stock products fetched', {
      adminId: req.user._id,
      threshold,
      count: lowStockProducts.length
    });

    res.json({
      products: lowStockProducts,
      threshold,
      count: lowStockProducts.length
    });
  } catch (error) {
    logger.error('Error fetching low stock products', {
      adminId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching low stock products' });
  }
};