const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { cartItemValidation } = require('../middleware/validation');
const logger = require('../utils/logger');

exports.getCart = async (req, res) => {
  try {
    const cart = await Cart.findByUserId(req.user._id);
    
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    let totalAmount = 0;
    const items = await Promise.all(cart.items.map(async (item) => {
      const product = await Product.findById(item.productId);
      const itemTotal = item.quantity * product.price;
      totalAmount += itemTotal;

      return {
        productId: item.productId,
        quantity: item.quantity,
        product: {
          _id: product._id,
          name: product.name,
          price: product.price,
          availableStock: product.availableStock,
          images: product.images,
          canFulfill: product.availableStock >= item.quantity
        },
        itemTotal
      };
    }));

    logger.info('Cart retrieved successfully', {
      userId: req.user._id,
      itemCount: items.length,
      totalAmount
    });

    res.json({
      items,
      totalAmount,
      totalItems: cart.totalItems
    });
  } catch (error) {
    logger.error('Error fetching cart', {
      userId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error fetching cart' });
  }
};

exports.addToCart = async (req, res) => {
  try {
    const { error } = cartItemValidation(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const { productId, quantity } = req.body;

    const product = await Product.findOne({ _id: productId, isActive: true });
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    if (product.availableStock < quantity) {
      return res.status(400).json({ 
        error: `Insufficient stock. Only ${product.availableStock} items available.` 
      });
    }

    let cart = await Cart.findOne({ userId: req.user._id });
    
    if (!cart) {
      cart = new Cart({ userId: req.user._id, items: [] });
    }

    await cart.addItem(productId, quantity);
    await cart.populate('items.productId', 'name price availableStock images');

    logger.info('Item added to cart', {
      userId: req.user._id,
      productId,
      quantity,
      cartId: cart._id
    });

    res.json({
      message: 'Item added to cart successfully',
      cart: {
        _id: cart._id,
        items: cart.items,
        totalItems: cart.totalItems
      }
    });
  } catch (error) {
    logger.error('Error adding item to cart', {
      userId: req.user._id,
      productId: req.body.productId,
      error: error.message
    });
    res.status(500).json({ error: 'Server error adding item to cart' });
  }
};

exports.updateCartItem = async (req, res) => {
  try {
    const { quantity } = req.body;
    const { productId } = req.params;

    if (!quantity || quantity < 0) {
      return res.status(400).json({ error: 'Valid quantity is required' });
    }

    const cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    const product = await Product.findOne({ _id: productId, isActive: true });
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const existingItem = cart.items.find(item => 
      item.productId.toString() === productId
    );

    if (existingItem && quantity > existingItem.quantity) {
      const quantityIncrease = quantity - existingItem.quantity;
      if (product.availableStock < quantityIncrease) {
        return res.status(400).json({ 
          error: `Insufficient stock. Only ${product.availableStock} additional items available.` 
        });
      }
    }

    await cart.updateQuantity(productId, quantity);
    await cart.populate('items.productId', 'name price availableStock images');

    logger.info('Cart item updated', {
      userId: req.user._id,
      productId,
      quantity,
      cartId: cart._id
    });

    res.json({
      message: 'Cart item updated successfully',
      cart: {
        _id: cart._id,
        items: cart.items,
        totalItems: cart.totalItems
      }
    });
  } catch (error) {
    logger.error('Error updating cart item', {
      userId: req.user._id,
      productId: req.params.productId,
      error: error.message
    });
    res.status(500).json({ error: 'Server error updating cart item' });
  }
};

exports.removeFromCart = async (req, res) => {
  try {
    const { productId } = req.params;

    const cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    await cart.removeItem(productId);
    await cart.populate('items.productId', 'name price availableStock images');

    logger.info('Item removed from cart', {
      userId: req.user._id,
      productId,
      cartId: cart._id
    });

    res.json({
      message: 'Item removed from cart successfully',
      cart: {
        _id: cart._id,
        items: cart.items,
        totalItems: cart.totalItems
      }
    });
  } catch (error) {
    logger.error('Error removing item from cart', {
      userId: req.user._id,
      productId: req.params.productId,
      error: error.message
    });
    res.status(500).json({ error: 'Server error removing item from cart' });
  }
};

exports.clearCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user._id });
    if (!cart) {
      return res.status(404).json({ error: 'Cart not found' });
    }

    await cart.clear();

    logger.info('Cart cleared', {
      userId: req.user._id,
      cartId: cart._id
    });

    res.json({ message: 'Cart cleared successfully' });
  } catch (error) {
    logger.error('Error clearing cart', {
      userId: req.user._id,
      error: error.message
    });
    res.status(500).json({ error: 'Server error clearing cart' });
  }
};