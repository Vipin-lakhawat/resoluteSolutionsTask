const mongoose = require('mongoose');
const { ORDER_STATUS } = require('../../config/constants');

const orderItemSchema = new mongoose.Schema({
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: [true, 'Product ID is required']
  },
  quantity: {
    type: Number,
    required: [true, 'Quantity is required'],
    min: [1, 'Quantity must be at least 1']
  },
  priceAtPurchase: {
    type: Number,
    required: [true, 'Price at purchase is required'],
    min: [0, 'Price cannot be negative']
  },
  productName: {
    type: String,
    required: [true, 'Product name is required']
  },
  productImage: {
    type: String,
    default: null
  }
});

const orderSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  items: [orderItemSchema],
  totalAmount: {
    type: Number,
    required: [true, 'Total amount is required'],
    min: [0, 'Total amount cannot be negative']
  },
  status: {
    type: String,
    enum: Object.values(ORDER_STATUS),
    default: ORDER_STATUS.PENDING_PAYMENT
  },
  paymentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Payment'
  },
  shippingAddress: {
    street: String,
    city: String,
    state: String,
    country: String,
    zipCode: String
  },
  expiresAt: {
    type: Date,
    default: function() {
      return new Date(Date.now() + 15 * 60 * 1000); 
    }
  },
  notes: {
    type: String,
    maxlength: [500, 'Notes cannot exceed 500 characters']
  }
}, {
  timestamps: true
});


orderSchema.index({ userId: 1, createdAt: -1 });
orderSchema.index({ status: 1 });
orderSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });
orderSchema.index({ createdAt: -1 });

orderSchema.virtual('isExpired').get(function() {
  return this.expiresAt < new Date() && this.status === ORDER_STATUS.PENDING_PAYMENT;
});

orderSchema.methods.canBeCancelled = function() {
  return [ORDER_STATUS.PENDING_PAYMENT, ORDER_STATUS.PAID].includes(this.status);
};

orderSchema.methods.updateStatus = async function(newStatus) {
  const validTransitions = {
    [ORDER_STATUS.PENDING_PAYMENT]: [ORDER_STATUS.PAID, ORDER_STATUS.CANCELLED],
    [ORDER_STATUS.PAID]: [ORDER_STATUS.SHIPPED, ORDER_STATUS.CANCELLED],
    [ORDER_STATUS.SHIPPED]: [ORDER_STATUS.DELIVERED],
    [ORDER_STATUS.DELIVERED]: [],
    [ORDER_STATUS.CANCELLED]: []
  };

  if (!validTransitions[this.status].includes(newStatus)) {
    throw new Error(`Invalid status transition from ${this.status} to ${newStatus}`);
  }

  this.status = newStatus;
  return await this.save();
};

orderSchema.statics.findByUserId = function(userId, page = 1, limit = 10) {
  const skip = (page - 1) * limit;
  
  return this.find({ userId })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .populate('paymentId', 'transactionId amount status')
    .exec();
};

orderSchema.statics.getOrdersSummary = function(userId) {
  return this.aggregate([
    { $match: { userId: mongoose.Types.ObjectId.createFromHexString(userId) } },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
        totalAmount: { $sum: '$totalAmount' }
      }
    }
  ]);
};

orderSchema.pre('save', function(next) {
  if (this.isModified('items')) {
    const hasNegativeQuantity = this.items.some(item => item.quantity <= 0);
    if (hasNegativeQuantity) {
      return next(new Error('All items must have a quantity greater than 0'));
    }
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);