const mongoose = require('mongoose');
const { PAYMENT_STATUS } = require('../../config/constants');

const paymentSchema = new mongoose.Schema({
  orderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Order',
    required: [true, 'Order ID is required']
  },
  transactionId: {
    type: String,
    required: [true, 'Transaction ID is required'],
    unique: true,
    trim: true
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0, 'Amount cannot be negative']
  },
  status: {
    type: String,
    enum: Object.values(PAYMENT_STATUS),
    required: [true, 'Payment status is required']
  },
  paymentMethod: {
    type: String,
    default: 'credit_card',
    enum: ['credit_card', 'debit_card', 'paypal', 'bank_transfer']
  },
  paymentGateway: {
    type: String,
    default: 'mock_gateway'
  },
  gatewayResponse: {
    type: mongoose.Schema.Types.Mixed,
    default: null
  },
  refundedAmount: {
    type: Number,
    default: 0,
    min: 0
  },
  isRefunded: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

paymentSchema.index({ orderId: 1 });
paymentSchema.index({ createdAt: -1 });
paymentSchema.index({ status: 1 });

paymentSchema.methods.markAsRefunded = async function(refundAmount = this.amount) {
  if (refundAmount > this.amount - this.refundedAmount) {
    throw new Error('Refund amount exceeds available amount');
  }
  
  this.refundedAmount += refundAmount;
  this.isRefunded = this.refundedAmount === this.amount;
  return await this.save();
};

paymentSchema.methods.canRefund = function() {
  return this.status === PAYMENT_STATUS.SUCCESS && 
         !this.isRefunded && 
         this.refundedAmount < this.amount;
};

paymentSchema.statics.findByOrderId = function(orderId) {
  return this.findOne({ orderId }).exec();
};

paymentSchema.statics.getTotalRevenue = function(startDate, endDate) {
  const matchStage = {
    status: PAYMENT_STATUS.SUCCESS,
    createdAt: {}
  };
  
  if (startDate) matchStage.createdAt.$gte = new Date(startDate);
  if (endDate) matchStage.createdAt.$lte = new Date(endDate);
  
  return this.aggregate([
    { $match: matchStage },
    {
      $group: {
        _id: null,
        totalRevenue: { $sum: '$amount' },
        totalTransactions: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('Payment', paymentSchema);