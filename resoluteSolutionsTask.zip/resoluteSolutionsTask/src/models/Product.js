const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Product name is required'],
    trim: true,
    minlength: [2, 'Product name must be at least 2 characters long'],
    maxlength: [100, 'Product name cannot exceed 100 characters']
  },
  price: {
    type: Number,
    required: [true, 'Product price is required'],
    min: [0, 'Price cannot be negative'],
    validate: {
      validator: function(value) {
        return value >= 0;
      },
      message: 'Price must be a positive number'
    }
  },
  description: {
    type: String,
    required: [true, 'Product description is required'],
    minlength: [10, 'Description must be at least 10 characters long'],
    maxlength: [1000, 'Description cannot exceed 1000 characters']
  },
  availableStock: {
    type: Number,
    required: [true, 'Available stock is required'],
    min: [0, 'Stock cannot be negative'],
    default: 0
  },
  reservedStock: {
    type: Number,
    min: [0, 'Reserved stock cannot be negative'],
    default: 0
  },
  images: [{
    type: String,
    validate: {
      validator: function(url) {
        return /^https?:\/\/.+\..+/.test(url);
      },
      message: 'Please provide a valid image URL'
    }
  }],
  category: {
    type: String,
    trim: true,
    default: 'General'
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

productSchema.virtual('totalStock').get(function() {
  return this.availableStock + this.reservedStock;
});

productSchema.index({ name: 'text', description: 'text' });
productSchema.index({ category: 1 });
productSchema.index({ price: 1 });
productSchema.index({ isActive: 1 });

productSchema.methods.reserveStock = async function(quantity) {
  if (this.availableStock < quantity) {
    throw new Error(`Insufficient stock available. Available: ${this.availableStock}, Requested: ${quantity}`);
  }
  
  this.availableStock -= quantity;
  this.reservedStock += quantity;
  return await this.save();
};

productSchema.methods.releaseStock = async function(quantity) {
  if (this.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock. Reserved: ${this.reservedStock}, Requested to release: ${quantity}`);
  }
  
  this.reservedStock -= quantity;
  this.availableStock += quantity;
  return await this.save();
};

productSchema.methods.confirmStockReduction = async function(quantity) {
  if (this.reservedStock < quantity) {
    throw new Error(`Insufficient reserved stock. Reserved: ${this.reservedStock}, Requested to confirm: ${quantity}`);
  }
  
  this.reservedStock -= quantity;
  return await this.save();
};

productSchema.methods.addStock = async function(quantity) {
  if (quantity <= 0) {
    throw new Error('Stock quantity must be positive');
  }
  
  this.availableStock += quantity;
  return await this.save();
};

productSchema.statics.getLowStockProducts = function(threshold = 10) {
  return this.find({
    availableStock: { $lte: threshold },
    isActive: true
  });
};

module.exports = mongoose.model('Product', productSchema);