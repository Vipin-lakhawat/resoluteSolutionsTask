const Redis = require('redis');
const logger = require('../src/utils/logger');

const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  ...(process.env.REDIS_PASSWORD && { password: process.env.REDIS_PASSWORD })
};

const createRedisClient = () => {
  const client = Redis.createClient(redisConfig);

  client.on('connect', () => {
    logger.info('Redis client connected');
  });

  client.on('error', (err) => {
    logger.error('Redis client error:', err);
  });

  client.on('end', () => {
    logger.warn('Redis client disconnected');
  });

  return client;
};

module.exports = { createRedisClient, redisConfig };