module.exports = {
  ORDER_STATUS: {
    PENDING_PAYMENT: 'PENDING_PAYMENT',
    PAID: 'PAID',
    SHIPPED: 'SHIPPED',
    DELIVERED: 'DELIVERED',
    CANCELLED: 'CANCELLED'
  },
  
  PAYMENT_STATUS: {
    SUCCESS: 'SUCCESS',
    FAILED: 'FAILED'
  },
  
  USER_ROLES: {
    USER: 'USER',
    ADMIN: 'ADMIN'
  },
  
  ORDER_EXPIRY_MINUTES: 15,
  
  PAGINATION: {
    DEFAULT_PAGE: 1,
    DEFAULT_LIMIT: 10,
    MAX_LIMIT: 100
  },
  
  RATE_LIMITING: {
    WINDOW_MS: 15 * 60 * 1000, 
    MAX_REQUESTS: 100
  }
};